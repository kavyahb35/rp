<?php
   require_once("Rest.inc.php");
   
   class API extends REST {
   
       public $data = "";
       const DB_SERVER = "localhost";
       const DB_USER = "rewards2pay";
       const DB_PASSWORD = "Gzah215LE!IJ";
       const DB = "rewards2pay";
       const BASEURL = 'http://r2p.cueserve.com/';   
   
       private $db = NULL;
       public function __construct(){
            parent::__construct();				
            $this->dbConnect();					
       }
       
       /*   Database connection  */
       private function dbConnect(){
           $this->db = mysqli_connect(self::DB_SERVER,self::DB_USER,self::DB_PASSWORD,self::DB);
            if (mysqli_connect_errno())
              {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
              }
       }
   
       public function processApi(){
           $func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));
           if((int)method_exists($this,$func) > 0)
               $this->$func();
           else
               $this->response('',404);				
       }
       
      /* get json file read in fakedb */
      public function getfileresponse()
       {
		   $base_url = self::BASEURL;
           $filename = $_REQUEST['filename'];
           $path=$base_url.'fakedb/'.$filename; 
           $str = file_get_contents($path);
           $this->response($str, 200);
           $this->response('',404);
   
       }
       
      /* get json file read in jsondb */
       public function getfileresponsebyclient()
       {
           $base_url = self::BASEURL;
           $filename = $_REQUEST['filename'];
           $path=$base_url.'jsondb/'.$filename; 
           $str = file_get_contents($path);
           $this->response($str, 200);
           $this->response('',404);
   
       }
       
       private function json($data){
               if(is_array($data)){
                       return json_encode($data);
               }
       }
   }
   
   // Initiiate Library
   
   $api = new API;
   $api->processApi();
   ?>
