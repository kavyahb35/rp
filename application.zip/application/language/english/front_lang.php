<?php
// Heading
$lang['heading_title']					= 'Membership Card';

// Text
$lang['text_success']           		= 'Success: You have modified membership card!';
$lang['text_day']						= 'Day';
$lang['text_week']						= 'Week';
$lang['text_semi_month']				= 'Semi Month';
$lang['text_month']						= 'Month';
$lang['text_year']						= 'Year';
$lang['text_yes']						= 'Yes';
$lang['text_no']						= 'No';
$lang['text_enabled']					= 'Enabled';
$lang['text_disabled']					= 'Disabled';

// Entry
$lang['entry_name']					    = 'Name';
$lang['entry_image']					= 'Image';
$lang['entry_price']					= 'Price';
$lang['entry_quantity']					= 'Quantity';
$lang['entry_duration']					= 'Subscription Duration';
$lang['entry_cycle']					= 'Subscription Cycle';
$lang['entry_frequency']				= 'Subscription Frequency';
$lang['entry_trial']				    = 'Subscription Trial';
$lang['entry_recurring']				= 'Subscription';

// Error
$lang['error_permission']				= 'Warning: You do not have permission to modify membership cardl!';
$lang['error_name']					    = 'Membership name must be between 3 and 32 characters!!';