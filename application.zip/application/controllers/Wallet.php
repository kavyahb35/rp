<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wallet extends CI_Controller {	
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    
    /* Fetch Loyalty program list API Call */
    public function index()
    {
        $data = array();
        $this->App->checkCustomerAuthenticate();
        $data['main']='customer/wallet';
        $data['title']='Rewards2pay wallet';
        $data['metadescription']='';
        $data['metakeyword']='';
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken']; 
        
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');        
         
        if($flag==true){       
            // get all program list
            $apiurl = base_url().'restapi/getfileresponsebyclient?filename=allprogramlist.json';
            $datas = array('filename'=>"allprogramlist.json");
            $senddata = json_encode($datas);           
            
            // get user program list
            $apiurl1 = $this->config->item('api_url');
            $apiurl1 = $apiurl1.'getfileresponse?filename=userprogramlistmy.json';
            $datas1 = array('filename'=>"userprogramlistmy.json");
        } else{
            // Call getloyaltyprograminfo API
            $apiurl = $this->config->item('api_url');
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo);          
            
            // Call fetchUserRewards API
            $apiurl1 = $this->config->item('api_url');
            $apiurl1 = $apiurl1.'fetchUserRewards/';
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);
        }      
        
         $curl = curl_init();
          curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data['error']=$err;
        } else {
            if(!empty($response)){
                $respe = json_decode($response); 
            }              
        }
       
        // -- for get perticular user  program
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl1,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata1,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         $data['error']=$err;
        } else {
          if(!empty($responses)){
             $respes = json_decode($responses);              
          }              
        }
        $data['success'] = $this->arrayMerge($respe, $respes);
        
        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data); 
    }
    
    /* Merge two array function */
    public function arrayMerge($first,$second)
    {
        $new = array();
        foreach($first as $key => $value){
            foreach($second as $value2){  
                if($value->progId === $value2->progId){  
                    $new[] = array(
                        'progId'=>$value2->progId,
                        'programName'=>$value2->programName,
                        'pointBalance'=>$value2->pointBalance,
                        'pointBalance1'=>$value2->pointBalance1,
                        'pointsSoftBalance'=>$value2->pointsSoftBalance,
                        'lastUpdated'=>$value2->lastUpdated,
                        'active'=>$value2->active,
                        'canRedeem'=>$first[$key]->canRedeem,
                        'minimumBalance'=>$first[$key]->minPointsEntered,
                        'cashBalance'=>$value2->cashBalance                       
                    );                    
                }               
            }
        }
        return $new;
    }
    
    /* Refresh point API call */
    public function refreshpoins()
    {
        $this->App->checkCustomerAuthenticate();
        $programid = $this->input->post('programid');
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken == ''){
            $message = $this->App->authgenerate();
            if($message == 'success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               // $err = $accessToken;	
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];        
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
        if($flag == true){
            $apiurl = $apiurl.'getfileresponse?filename=refreshrewardspointsvalid.json';
            $datas = array('filename'=>"refreshrewardspointsvalid.json");
            $senddata = json_encode($datas);
        }
        else {
            $apiurl = $apiurl.'refreshPointBalance/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $rewardsProgramInfo = array('progId'=>$programid);
            
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardsProgramInfo'=>$rewardsProgramInfo);
            $senddata = json_encode($merge);
        }      
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
              "Content-Type: application/json",
              "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data['error']=$err;
        } else {
            if(!empty($response)) {
                $respe = json_decode($response);
                if($respe->message!='' ){
                    $data['err']='2';
                    $error = $respe->message;
                    $contact = base_url();
                    $error .='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                    $data['error']=$error;
                }
                if(!empty($respe)) {
                    $data['succ']='1';
                }
                echo json_encode($data);
             }              
        }
    }
    
    /* Remove program API call */
    public function removepoins()
    {
        $this->App->checkCustomerAuthenticate();
        $programid = $this->input->post('programid');
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
         if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];        
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
        if($flag==true){
            $apiurl = $apiurl.'getfileresponse?filename=removerewardspoinsvalid.json';
            $datas = array('filename'=>"removerewardspoinsvalid.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $apiurl.'removeUserRewards';
            $partnerId = $this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $rewardsProgramInfo = array('progId'=>$programid);
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
            $senddata = json_encode($merge);
        }   
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));


        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
        if ($err) {
            $data['error']=$err;
            $data['err'] ='2';
            echo json_encode($data);
        } else {
            if(!empty($response)){
                $respe = json_decode($response);
                if($respe->message!=''){
                    $data['err']='2';
                    $error = $respe->message;
                    $contact = base_url();
                    $error .='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                    $data['error']=$error;
                }
                if($respe->statusMessage!=''){
                   $data['success'] = $respe->statusMessage;
                   $statusCode=$respe->statusCode;
                   if($statusCode=='0'){
                       $data['success'] = $respe->statusMessage;
                       $data['err']='2';
                   }
                   if($statusCode=='1'){
                       $data['error'] = $respe->statusMessage;
                       $data['succ']='1';
                   }
                }
                echo json_encode($data);
            }              
        }
    }

    /* Redeem value API Call*/
    public function redeemvaluefuncion()
    {
        $programid = $this->input->post('programid');
        $programidname = $this->input->post('programidname');
        $minimumBalance = $this->input->post('minimumBalance');
        $redeemvalue = $this->input->post('redeemvalue');
        $cashvalue = $this->input->post('cashvalue');
        $pointBalance = $this->input->post('pointBalance');
       
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
         if($accessToken == ''){
                $message = $this->App->authgenerate();
            if($message == 'success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
              
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
       
        $this->form_validation->set_rules('redeemvalue', 'Point Value', 'required');
        $minimumBalance1 = $minimumBalance;
        if($redeemvalue < $minimumBalance1){
            $err1 = 'You have entered insufficient balance points to redeem.';
        }
        if($redeemvalue > $pointBalance){
            $err = 'You have entered insufficient balance points to redeem.';
        }
        
        if($this->form_validation->run() == FALSE || $err != '' || $err1 != ''){
            if (validation_errors() != ''|| $err!='' || $err1!='') {
                $data['error'] = validation_errors().$err.$err1;
                $data['error'] = str_ireplace('</p>','',$data['error']);
                $data['error'] = str_ireplace('<p>','',$data['error']);
                $data['err'] = '2';
                echo json_encode($data);
            }
        } else {
            $apiurl = $this->config->item('api_url');
            $flag = $this->config->item('usedstaticdata');
            if($flag==true){
                $apiurl = $apiurl.'getfileresponse?filename=redeempointbalancevalid.json';
                $datas = array('filename'=>"redeempointbalancevalid.json");
                $senddata = json_encode($datas);
            }
            else{
                $apiurl = $apiurl.'redeempointsorcash';
                $partnerId =$this->config->item('partnerId');
                $partnerName =$this->config->item('partnerName');
                
                $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);                
                $rewardsProgramInfo = array('progId'=>$programid,'pointBalance1'=>$redeemvalue,'cashBalance'=>$cashvalue,'cpFlag'=>'P');
                
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
                $senddata = json_encode($merge);

            }     

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json",
                    "access-token: ".$accessToken
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            
            if ($err) {
                $data['error']=$err;
                $data['err'] ='2';
                echo json_encode($data);
            } else {
                if(!empty($response)){
                    $respe = json_decode($response);
                    $errormsg = $respe->message;
                    if(!empty($respe)){
                        if($errormsg!=''){
                            $data['error'] = $errormsg;
                            $data['err']='2';
                        }else{
                           if($respe->progId!=''){
                                $data['pointBalance1']=$respe->pointBalance1;
                                $data['cashBalance']=$respe->cashBalance;
                                $data['succ']='1';


                            }else{
                                $contact = base_url();
                                $data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                                $data['err']='2';
                            }
                        }
                    }
                    echo json_encode($data);
                }
            }            
        }       
    }
    
    /* Redeem Cash Value API */
    public function cashvaluefuncion()
    {
        $programid = $this->input->post('programid');
        $programidname = $this->input->post('programidname');
        $minimumBalance = $this->input->post('minimumBalance');
        $redeemvalue = $this->input->post('redeemvalue');
        $cashvalue = $this->input->post('cashvalue');
        $pointBalance = $this->input->post('pointBalance');
       
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
         if($accessToken==''){
             $message = $this->App->authgenerate();
            if($message=='success'){
                 $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               // $err = $accessToken;	
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
       
        $this->form_validation->set_rules('cashvalue', 'Cash Value', 'required');
        
        if ($this->form_validation->run() == FALSE ) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
                $data['error'] = str_ireplace('</p>','',$data['error']);
                $data['error'] = str_ireplace('<p>','',$data['error']);
                $data['err'] = '2';
                echo json_encode($data);
            }
        } else {
            $apiurl = $this->config->item('api_url');
            $flag = $this->config->item('usedstaticdata');
            if($flag==true){
                $apiurl = $apiurl.'getfileresponse?filename=redeempointbalancevalid.json';
                $datas = array('filename'=>"redeempointbalancevalid.json");
                $senddata = json_encode($datas);
            }
            else{
                $apiurl = $apiurl.'redeempointsorcash';
                $partnerId = $this->config->item('partnerId');
                $partnerName = $this->config->item('partnerName');
                
                $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                $rewardsProgramInfo = array('progId'=>$programid,'pointBalance1'=>$redeemvalue,'cashBalance'=>$cashvalue,'cpFlag'=>'C');
                
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
                $senddata = json_encode($merge);

            }     

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json",
                    "access-token: ".$accessToken
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            
            if ($err) {
                $data['error']=$err;
                $data['err'] ='2';
                echo json_encode($data);
            } else {
                if(!empty($response)){
                    $respe = json_decode($response);

                    $errormsg = $respe->message;
                    if(!empty($respe)){
                        if($errormsg != ''){
                            $data['error'] = $errormsg;
                            $data['err'] = '2';
                        }else{
                            if($respe->progId != ''){
                                $data['pointBalance1'] = $respe->pointBalance1;
                                $data['cashBalance'] = $respe->cashBalance;
                                $data['succ'] = '1';
                            }else{
                                $contact = base_url();
                                $data['error'] = 'please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                                $data['err'] = '2';
                            }
                        }
                    }
                    echo json_encode($data);
                 }
            }            
        }       
    }
    
    /* Confirm redeem point API Call */
    public function confirmpointredeem($progflag)
    {		
        $programflag = $progflag;
        $programid = $this->input->post('programid');
        $programidname = $this->input->post('programidname');
        $minimumBalance = $this->input->post('minimumBalance');
        $redeemvalue = $this->input->post('redeemvalue');
        $cashvalue = $this->input->post('cashvalue');
        $pointBalance = $this->input->post('pointBalance');
       
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
         if($accessToken==''){
                $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
       
        if($progflag=='C'){
            $this->form_validation->set_rules('cashvalue', 'Cash Value', 'required');
        }
        if($progflag=='P'){
            $this->form_validation->set_rules('pointBalance', 'Point Value', 'required');
        }
     
        if ($this->form_validation->run() == FALSE ) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
                $data['error'] = str_ireplace('</p>','',$data['error']);
                $data['error'] = str_ireplace('<p>','',$data['error']);
                $data['err'] = '2';
                echo json_encode($data);
            }
        } else {
            $apiurl = $this->config->item('api_url');
            $flag = $this->config->item('usedstaticdata');
            
            if($flag==true){
                $apiurl = $apiurl.'getfileresponse?filename=confirmpointredeem.json';
                $datas = array('filename'=>"confirmpointredeem.json");
                $senddata = json_encode($datas);
            }
            else{
                $apiurl = $apiurl.'confirmpointredemption';
                $partnerId =$this->config->item('partnerId');
                $partnerName =$this->config->item('partnerName');
                
                $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                $rewardsProgramInfo = array('progId'=>$programid,'pointBalance1'=>$redeemvalue,'cashBalance'=>$cashvalue,'cpFlag'=>$progflag);
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
                
                $senddata = json_encode($merge);
            }     

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json",
                    "access-token: ".$accessToken
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
           
            if ($err) {
                $data['error']=$err;
                $data['err'] ='2';
                echo json_encode($data);
            } else {
                if(!empty($response)){
                    $respe = json_decode($response);
                    if(!empty($respe)){
                        if($errormsg != ''){
                            $data['error'] = $errormsg;
                            $data['err'] = '2';
                        }else{
                            if($respe->id!=''){
                                if($respe->wallet->walletBalance!=''){
                                    $walletbal = $respe->wallet->walletBalance;
                                    $softWalletBalance = $respe->wallet->softWalletBalance;
                                    $estimatedWalletValue = $respe->wallet->estimatedWalletValue;
                                    $walletdata = array(
                                        'walletbalance' =>  $walletbal,
                                        'softWalletBalance' =>  $softWalletBalance,
                                        'estimatedWalletValue' =>  $estimatedWalletValue,
                                    );

                                    $this->session->set_userdata('walletCustomerDetails', $walletdata);
                                    $data['success'] = 'Your wallet balancen : '.$walletbal .' and softWallet Balance is '.$softWalletBalance.' and estimated Wallet Value is '.$estimatedWalletValue;
                                    $data['succ']='1';
                                }else{
                                    $contact = base_url();
                                    $data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                                    $data['err']='2';
                                }
                                $data['succ']='1';

                            }else{
                                $contact = base_url();
                                $data['error'] = 'please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                                $data['err'] = '2';
                            }
                        }
                    }
                    echo json_encode($data);
                }
            }            
        }
    }
            
    
}
