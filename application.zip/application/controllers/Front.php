<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    
    /* Call Home page */
    public function index()
    {
        $data = array();
        $this->App->authgenerate();
        
        $filename = 'faq.json';
        $data['title'] = 'Rewards2pay';
        $apiurl  = base_url();
        $path = $apiurl . 'jsondb/' . $filename;
        $str = file_get_contents($path);
        $data['faqs'] = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $str), true); 
               
        $this->load->vars($data);
        $this->load->view('front/front');
    }
    
    /* Call Contact us Section */
    public function contact()
    {        
        $this->form_validation->set_rules('fname', 'Name', 'required');
        $this->form_validation->set_rules('cemail', 'Email', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('message', 'Message', 'required');
        
        if ($this->form_validation->run() == FALSE) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
                echo json_encode($data);
            }
        } else {
            $arr = array(
                'UserName' => $this->input->post('fname'),
                'Email' => $this->input->post('cemail'),
                'Subject' => $this->input->post('subject'),
                'Message' => $this->input->post('message'),
                'Created' => date('Y-m-d')
            );
            $this->App->insertdata('r2p_contact', $arr);
            
            /* Starting Email functionality */
              
            $logo = base_url('assets/front/home/theme-assets/images/logo.png');
            $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                        <img src="'.$logo.'">
                        </h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        Thank You for Contact us. We will get back to soon. <br>
                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Rewards2Pay.com.</p>
                        </div></div></div></div>';
            
            $from_email = $this->config->item('emailset');
          
            $email = $this->input->post('cemail');
            $name = $this->input->post('fname');
            $subject = $this->input->post('subject');
            $message = $this->input->post('message');
            
            $to = $cemail;
            $subject = "Thank you for Contact us with rewards2pay.com";
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: ".$from_email;
            
            $message = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                        Rewards2pay.com </h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        Thank You for Contact us. We will get back to soon. <br>
                        </div>
                        <p class="footer" style="font-size: 11px;border-top: 1px solid #D0D0D0; line-height: 32px; padding: 0 10px 0 10px; margin: 20px 0 0 0;text-align: center;background: #333;color: #FFF;">Thank you for working with us. We look forward to seeing you on Rewards2Pay.com.</p>
                        </div></div></div></div>';
            
            
            mail($to, $subject, $message, $headers);
            
            $message1 = '<div style="background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, Arial, sans-serif;color: #4F5155;">
                        <div id="container" style="margin: 10px;border: 1px solid #D0D0D0;box-shadow: 0 0 8px #D0D0D0;">
                        <h1 style="color: #fff;background-color: #333;border-bottom: 1px solid #D0D0D0; font-size: 19px;font-weight: normal;margin: 0 0 14px 0;padding: 14px 15px 10px 15px; text-align: center;background: #333;">
                        Rewards2pay.com</h1>
                        <div id="body" style="margin: 0 15px 0 15px;text-align: center;">
                        <h3> Contact Details </h3><br>
                        Name : ' . $name . ' <br>
                        Email : ' . $email . ' <br>
                        Subject: ' . $subject . ' <br>
                        Message: ' . $message . ' <br>
                        </div>
                        </div></div>';
            $to12 = $from_email;
            mail($to12, $subject, $message1, $headers);
            
            /* Ending Email functionality */
            
            $data['success'] = 'Thank you for Contact us. We will get back soon.';
            echo json_encode($data);
        }        
    }
    
}
