<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Faq extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
    }    
    
    /* Call FAQ page in user panel */
    public function index()
    {
        $data = array();
        $this->App->checkCustomerAuthenticate();
        $data['main'] = 'customer/faq';
        $data['title'] = 'Rewards2pay FAQ';
        $data['metadescription'] = 'FAQ';
        $data['metakeyword'] = 'FAQ';
        
        $filename  = 'faq.json';
        $data['title'] = 'Rewards2pay';
        $apiurl = base_url();
        $path = $apiurl . 'jsondb/' . $filename;
        $str = file_get_contents($path);
        $data['faqs']  = json_decode(preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $str), true);  
        
        $this->load->vars($data);
        $this->load->view('customer/templates/inner', $data);
    }    
}
