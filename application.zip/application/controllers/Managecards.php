<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ManageCards extends CI_Controller {	
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    
    /* Call All program list API and fetch user rewards API */
    public function index()
    {
        $data = array();
        
        $this->App->checkCustomerAuthenticate();
        
        $data['main'] = 'customer/manage_cards';
        $data['title'] = 'Manage Card';
        $data['metadescription'] = '';
        $data['metakeyword'] = '';
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
				
            }
        }
        
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
                
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
            
        if($flag == true) {    
            // get all program list      
            $apiurl = base_url().'restapi/getfileresponsebyclient?filename=allprogramlist.json';
            $datas = array('filename'=>"allprogramlist.json");
            $senddata = json_encode($datas);
            
            // get user program list
            $apiurl1 = $this->config->item('api_url');
            $apiurl1 = $apiurl1.'getfileresponse?filename=userprogramlistmy.json';
            $senddata1= array('filename'=>"userprogramlistmy.json");
        } else {
            // get all program list    
            $apiurl = $this->config->item('api_url');
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo); 
            
            // get user program list    
            $apiurl1 = $this->config->item('api_url');
            $apiurl1 = $apiurl1.'fetchUserRewards/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);
        }      
        // get all program list 
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            $data['error'] = $err;
        } else {
            if(!empty($response)){
                $respe = json_decode($response); 
            }              
        }
        
        // get user program list 
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl1,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata1,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            $data['error'] = $err;
        } else {
            if(!empty($responses)){
                $respes = json_decode($responses);              
            }              
        }
        
        if(!empty($respes)){
            $data['withoutLoginProgram'] = $this->array_diff_assoc_recursive($respe, $respes);    
        }else{
            foreach($respe as $evh){
                $newsarray[] = array(
                    'progId'=>$evh->progId,
                    'programName'=>$evh->programName,
                    'minPointsEntered'=>$evh->minPointsEntered,
                    'activeStatus'=>$evh->activeStatus,
                    'canManage'=>$evh->canManage,
                    'canMonitor'=>$evh->canMonitor,
                    'country'=>$evh->country,
                    'canRedeem'=>$evh->canRedeem,
                    'barcodeStandard'=>$evh->barcodeStandard             
                );
            }
            $data['withoutLoginProgram'] = $newsarray;  
        }      
        
        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data); 
    }
    
    /* Compare two array value and get common array value */
    function array_diff_assoc_recursive($array1, $array2)
    {     
        
        foreach($array1 as $aV){ 
            $aTmp1[] = $aV->progId;
        }

        foreach($array2 as $aV){
            $aTmp2[] = $aV->progId;
        }
  
        $new_array = array_diff($aTmp1,$aTmp2);        
        $i=0;
        foreach($array1 as $news){
            if (in_array($new_array[$i], $aTmp1)) {
                $newsarray[] = array(
                    'progId'=>$news->progId,
                    'programName'=>$news->programName,
                    'minPointsEntered'=>$news->minPointsEntered,
                    'activeStatus'=>$news->activeStatus,
                    'canManage'=>$news->canManage,
                    'canMonitor'=>$news->canMonitor,
                    'country'=>$news->country,
                    'canRedeem'=>$news->canRedeem,
                    'barcodeStandard'=>$news->barcodeStandard             
                );
            }
        $i++;
        }
       return $newsarray;
    }
    
    /* Add Loyalty Program API Call */
    public function addProgram()
    {
        $this->App->checkCustomerAuthenticate();
        $programid = $this->input->post('programid');
        $progUsername = $this->input->post('username');
        $progPwd = $this->input->post('password');
        $programidname = $this->input->post('programidname');
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
             $message = $this->App->authgenerate();
            if($message=='success'){
                 $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
              
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
        
        $this->form_validation->set_rules('username', 'User Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required'); 
        
         if ($this->form_validation->run() == FALSE ) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
                $data['error'] = str_ireplace('</p>','',$data['error']);
                $data['error'] = str_ireplace('<p>','',$data['error']);
                $data['err'] = '2';
                echo json_encode($data);
            }
        } else {
            $apiurl = $this->config->item('api_url');
            $flag = $this->config->item('usedstaticdata');
            if($flag == true){
                $apiurl = $apiurl.'getfileresponse?filename=addrewardsprogramvalid.json';
                $datas = array('filename'=>"addrewardsprogramvalid.json");
                $senddata = json_encode($datas);
            }
            else{
                $apiurl = $apiurl.'addUserRewards/';
                $partnerId =$this->config->item('partnerId');
                $partnerName =$this->config->item('partnerName');
                
                $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                $rewardsProgramInfo = array('progId'=>$programid,'progUsername'=>$progUsername,'progPwd'=>$progPwd);
                
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardsProgramInfo'=>$rewardsProgramInfo);
                $senddata = json_encode($merge);
            }   
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                  "Content-Type: application/json",
                  "access-token: ".$accessToken
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);
            if ($err) {
                $data['error']=$err;
                $data['err'] ='2';
                echo json_encode($data);
            } else {
              if(!empty($response)){                  
                    $respe = json_decode($response);
                    $errs = $respe->message;
                    if($errs!=''){
                        $data['error']=$errs;
                        $data['err'] ='2';
                        echo json_encode($data);
                    }else{
                        if($respe->progId!=''){
                            $data['success']=$programidname .' program added successfully.'; $data['succ']='1';
                        }else{
                            $contact = base_url();
                            $data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                            $data['err'] ='2';
                        }
                        echo json_encode($data);
                    }               
                }
            }
        }        
    }
    
    /* Update card API Call */
    public function addCardProgram()
    {        
        $this->App->checkCustomerAuthenticate();
        $programid = $this->input->post('programid');
        $cardnumber = $this->input->post('cardnumber');
        $programidname = $this->input->post('programidname');
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
					
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
        $this->form_validation->set_rules('cardnumber', 'Card Number', 'required');
        
         if ($this->form_validation->run() == FALSE ) {
            if (validation_errors() != '') {
                $data['error'] = validation_errors();
                $data['error']=str_ireplace('</p>','',$data['error']);
                $data['error']=str_ireplace('<p>','',$data['error']);
                $data['err']='2';
                echo json_encode($data);
            }
        } else {
            $apiurl = $this->config->item('api_url');
            $flag = $this->config->item('usedstaticdata');
            if($flag==true){
                $apiurl = $apiurl.'getfileresponse?filename=add_updatecardvalid.json';
                $datas = array('filename'=>"add_updatecardvalid.json");
                $senddata = json_encode($datas);
            }
            else{
                $apiurl = $apiurl.'updatecardnumber/';
                $partnerId =$this->config->item('partnerId');
                $partnerName =$this->config->item('partnerName');

                $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                $rewardsProgramInfo = array('progId'=>$programid,'cardNumber'=>$cardnumber);
                
                $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardsProgramInfo'=>$rewardsProgramInfo);
                $senddata = json_encode($merge);
            }     

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                  "Content-Type: application/json",
                  "access-token: ".$accessToken
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);
            if ($err) {
                $data['error']=$err;
                $data['err'] ='2';
                echo json_encode($data);
            } else {
                if(!empty($response)){
                  $respe = json_decode($response);
                  $errormsg = $respe->message;
                  if(!empty($respe)){
                      if($errormsg!=''){
                          $data['error'] = $errormsg;
                          $data['err']='2';
                      }else{
                          if($respe->statusCode=='1'){
                              $data['success']=$programidname .' program added successfully.';
                              $data['succ']='1';
                          }
                         else if($respe->statusCode=='0'){
                              $data['error']=$respe->statusMessage;
                              $data['err']='2';
                         }
                         else if($respe->statusCode==''){
                              $contact = base_url();
                              $data['error']='please <a href="'.$contact.'" target="_blank"> contact </a> to our support team.';
                              $data['err']='2';
                         }
                      }
                  }                
                  echo json_encode($data);
                }
            }
        }        
    }	
}
