<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    
    /* Call Transaction history API Call*/
    public function index()
    {
        $data = array();
        $this->App->checkCustomerAuthenticate();
        $data['main'] = 'customer/transaction';
        $data['title'] = 'Rewards2pay transaction history';
        $data['metadescription'] = '';
        $data['metakeyword'] = '';
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                
            }
        }
        
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];
        
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
        
        if($flag==true){
            $apiurl = $apiurl.'getfileresponse?filename=transactionvalid.json';
            $datas = array('filename'=>"transactionvalid.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $apiurl.'gettransactionhistory/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);
        }      
        $curl = curl_init();
            curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data['error']=$err;
        } else {
            if(!empty($response)){
                $respe = json_decode($response);
                $data['success']=$respe;
                $data['succ']='1';
            }              
        }

        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data); 
    }	
}
