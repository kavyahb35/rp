<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {	

    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
    }
    
    /* Login API Call */
    public function login()
    {
        $loguser = $this->session->userdata['customerDetails']['username'];        
        $data = array();
        $data['main'] = 'front/useraccess/login';
        $data['title'] = 'Rewards2pay Login';
        $data['metadescription'] = '';
        $data['metakeyword'] = '';

        $this->form_validation->set_rules('username', 'User Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required'); 
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               	
            }
        }			
        
        if($_POST){
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $flag = $this->config->item('usedstaticdata');
		if($flag == true){	
                    if($username == 'user' && $password == 'user123'){ 
                        
                    }else{
                       echo $err1 = 'Username and password does not exist.';
                    }
                }
        }
		 
        if ($this->form_validation->run() == FALSE || $err != '' || $err1 != '') {
            if (validation_errors() != '' || $err != '' || $err1 != '') {
                $data['error'] = validation_errors().$err.$err1;
            }
        } else {			
            try {
                $username = $this->input->post('username');
		$password = $this->input->post('password');
				
                $apiurl = $this->config->item('api_url');
                $partnerId =$this->config->item('partnerId');
                $partnerName =$this->config->item('partnerName');
		$flag = $this->config->item('usedstaticdata');
                
		if($flag==true){	
                    $apiurl = $apiurl.'getfileresponse?filename=loginsuccessapi.json';			
                    $datas = array('filename'=>"loginsuccessapi.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl = $this->config->item('api_url');
                    $apiurl=$apiurl.'loginuser/';
                    $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                    $credentials = array('userName'=>$username ,'newPassword'=>$password);	
                    $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
                    $senddata = json_encode($merge);
                }
				
		$curl = curl_init();
		curl_setopt_array($curl, array(
                    CURLOPT_URL => $apiurl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $senddata,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json",
                        "access_token: ".$accessToken
                    ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
		    $data['error'] = $err;
		} else {
                    $respe = json_decode($response);                   				
                    $errmsg = $respe->message;                     
                    if($errmsg!=''){		
                       $data['error'] = $respe->message;
                    }
                    $usetoken = $respe->userToken;
	
                    if($usetoken!=''){						
                        $arraydata = array(
                            'id' => $respe->id,
                            'lastUpdate' =>  $respe->lastUpdate,
                            'lastUpdatedBy' =>  $respe->lastUpdatedBy,
                            'firstName' => $respe->firstName,
                            'lastName' =>  $respe->lastName,
                            'address' =>  $respe->address,
                            'phone' => $respe->phone,
                            'userEmail' =>  $respe->userEmail,
                            'altPhone' =>  $respe->altPhone,
                            'zipCode' => $respe->zipCode,
                            'city' =>  $respe->city,
                            'dob' =>  $respe->dob,
                            'userToken' => $respe->userToken,
                            'tokenCreated' =>  $respe->tokenCreated,
                            'status' =>  $respe->status,
                            'resetCount' => $respe->resetCount,
                            'username' => $username,
                            'oldpassword'=>$this->input->post('password'),
                        );        
                        $this->session->set_userdata('customerDetails', $arraydata);
                        
                        $walletbal = $respe->wallet->walletBalance;
                        $softWalletBalance = $respe->wallet->softWalletBalance;
                        $estimatedWalletValue = $respe->wallet->estimatedWalletValue;
                        
                        $walletdata = array(
                            'walletbalance' =>  $walletbal,
                            'softWalletBalance' =>  $softWalletBalance,
                            'estimatedWalletValue' =>  $estimatedWalletValue,
                        );
                         $this->session->set_userdata('walletCustomerDetails', $walletdata);

                        // remember me code
                        $year = time() + 31536000;
                        if($_POST['remember']) {
                            setcookie('remember_meusername', $_POST['username'], $year);
                            setcookie('remember_mepassword', $_POST['password'], $year);
                        }
                        elseif(!$_POST['remember']) {
                            if(isset($_COOKIE['remember_meusername'])) {
                                $past = time() - 100;
                                setcookie(remember_me, gone, $past);
                            }
                            if(isset($_COOKIE['remember_mepassword'])) {
                                $past = time() - 100;
                                setcookie(remember_me, gone, $past);
                            }
                        }       
                        // end code
                        
                        redirect('dashboard');
                    }else{
                        $data['error'] = 'Invalid Username and Password';		
                    }		
                }
            }            
            catch (Exception $e)
            {
                $data['error']=$e;
            }		
	}
		
        $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
    }
	   	
    /* Register API Call */
    public function register()
    {
        $loguser = $this->session->userdata['customerDetails']['username'];
        if($loguser != ''){
            redirect('dashboard');
        }        
        $data = array();
        $data['main'] = 'front/useraccess/register';
        $data['title'] = 'Rewards2pay Register';
        $data['metadescription'] = '';
        $data['metakeyword'] = '';

        $this->form_validation->set_rules('username', 'User Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
        $this->form_validation->set_rules('firstname', 'First Name', 'required');
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('phone', 'Phone Number', 'required|min_length[10]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('zipcode', 'Zipcode', 'required');
        $this->form_validation->set_rules('dob', 'DoB', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('province', 'Province', 'required');
        $this->form_validation->set_rules('terms', 'Terms & condition', 'required');        
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            }else {
                $err = 'You are not  authenticated. Try again later';	
            }
        }
        if($_POST){            
            $password = $this->input->post('password');
            $jk = $this->App->password_strength_check($password);            
            if ($jk == '0') {
                $err1 = 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
            }	
            $username = $this->input->post('username');
            $ko = $this->App->username_strength_check($username);
            if ($ko == '0') {
                $err2 = '<br>Minimum 7 char required. Username must contain at least 1 digit & letter.';
            }		
	}
        
        if ($this->form_validation->run() == FALSE || $err!='' || $err1!='' || $err2!='') {
            if (validation_errors() != '' || $err!='' || $err1!='' || $err2!='') {
                $data['error'] = validation_errors().$err.$err1.$err2;
                $data['username'] = $this->input->post('username');
                $data['password'] = $this->input->post('password');
                $data['firstname'] = $this->input->post('firstname');
                $data['lastname'] = $this->input->post('lastname');
                $data['address'] = $this->input->post('address');
                $data['phone'] = $this->input->post('phone');
                $data['email'] = $this->input->post('email');
                $data['zipcode'] = $this->input->post('zipcode');
                $data['dob'] = $this->input->post('dob');
                $data['province'] = $this->input->post('province');
                $data['country'] = $this->input->post('country');
                $data['city'] = $this->input->post('city');
            }
        } else {	
            try {
                $username = $this->input->post('username');
                $password = $this->input->post('password');
                $firstname = $this->input->post('firstname');
                $lastname = $this->input->post('lastname');
                $address = $this->input->post('address');
                $phone = $this->input->post('phone');
                $email = $this->input->post('email');
                $zipcode = trim($this->input->post('zipcode'));
                $dob = $this->input->post('dob');
                $province = $this->input->post('province');
                $country = $this->input->post('country');
                $city = $this->input->post('city');

                $phone = str_replace("-","",$phone);
		$phone = str_replace(" ","",$phone);
                $newaddress = $address.' | '.$city.' | '.$province.'|'.$zipcode.' | '.$country;
                
                $apiurl = $this->config->item('api_url');
		$flag = $this->config->item('usedstaticdata');
		if($flag==true){
                    $apiurl = $apiurl.'getfileresponse?filename=registerapiresponse.json';
                    $datas = array('filename'=>"registerapiresponse.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl = $apiurl.'registerUser/';
                    $credentials = array('userName'=>$username ,'newPassword'=>$password);
                    $userDetails = array(
                        'firstName'=>$firstname,
                        'lastName'=>$lastname,
                        'address'=>$newaddress,
                        'phone'=>$phone,
                        'userEmail'=>$email,
                        'zipCode'=>$zipcode,
                        'dob'=>$dob,
                    );
                    $merge = array('credentials'=>$credentials,'userDetails'=>$userDetails);
                    $senddata = json_encode($merge);
                }
                
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $apiurl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $senddata,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json",
                        "access-token: ".$accessToken
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);

                if ($err) {
                    $response = json_decode($response);
                    $status = $response->error;
                    $error = $response->message;
                    $data['error'] = $err.' ' .$error;
                } else {
                    $response = json_decode($response);
                    $status = $response->statusCode;
                    $eoor = $response->message;
                    if($eoor!=''){
                        $data['error'] = $response->message;
                    }
                    $data['success'] = $response->statusMessage;
                }
            }
            catch (Exception $e)
            {
                $data['error']=$e;
            }	
	}
        
        $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
    }
	
    /* Forgot Password API Call */
    public function forgotpassword()
    {
        $data = array();
        $data['main']='front/useraccess/forgotpassword';
        $data['title']='Rewards2pay Forgot password';
        $data['metadescription']='';
        $data['metakeyword']='';
		
        $this->form_validation->set_rules('username', 'User Name', 'required');
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                $err = 'You are not  authenticated. Try again later';	
            }
        }
       
        if ($this->form_validation->run() == FALSE || $err!='' || $err1!='') {
            if (validation_errors() != '' || $err!='' || $err1!='') {
                $data['error'] = validation_errors().$err.$err1;
            }
        } else {			
            try {               
                $curl = curl_init();
		$apiurl = $this->config->item('api_url');
		$flag = $this->config->item('usedstaticdata');
		if($flag==true){		
                    $apiurl = $apiurl.'getfileresponse?filename=resetapiresponse.json';
                    $datas = array('filename'=>"resetapiresponse.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl=$apiurl.'resetPassword/';
                    $username = $this->input->post('username');
                    $credentials = array('userName'=>$username);
                    $senddata = json_encode($credentials);
                }		
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $apiurl,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $senddata,
                    CURLOPT_HTTPHEADER => array(
                        "Content-Type: application/json"
                    ),
                ));
                
                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);

                if ($err) {
                    $data['error']=$err;
                } else {
                    $respe = json_decode($response);					
                    $resetToken = $respe->userToken;
                    
                    if($resetToken!=''){                      
                        $data['success']= 'Please check your E-mail for reset password link. ';
                    }else {
                        if($respe->message!=''){
                            $data['error']=$respe->message;	
                        }
                    }
                }
            }
            catch (Exception $e)
            {
                $data['error']=$e;
            }	
	}
			
        $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
    }
    
    /* Reset Password API Call */
    public function resetpassword()
    {
        $data = array();
        $data['main']='front/useraccess/resetpassword';
        $data['title']='Rewards2pay Reset Password';
        $data['metadescription']='';
        $data['metakeyword']='';

        $this->form_validation->set_rules('username', 'User Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'required|matches[password]');
        if($_POST){
            $accessToken = $this->session->userdata['authDetails']['accessToken'];
            
            if($accessToken==''){
                $message = $this->App->authgenerate();
                if($message=='success'){
                    $accessToken = $this->session->userdata['authDetails']['accessToken'];
                }else {
                    $err = 'You are not  authenticated. Try again later';	
                }                
                $password = $this->input->post('confirmpassword');
                $jk = $this->App->password_strength_check($password);                
                if ($jk == '0') {
                    $err1 = 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
                }
            }			
        }
        
	if ($this->form_validation->run() == FALSE || $err!='' || $err1!='') {
            if (validation_errors() != '' || $err!='' || $err1!='') {
                $data['error'] = validation_errors().$err.$err1;               
            }
        } else {	
            try {                    
                $apiurl = $this->config->item('api_url');
                $flag = $this->config->item('usedstaticdata');
                if($flag==true){	
                    $apiurl = $apiurl.'getfileresponse?filename=updatepasswordresponse.json';
                    $datas = array('filename'=>"updatepasswordresponse.json");
                    $senddata = json_encode($datas);
                }
                else{
                    $apiurl = $apiurl."updatePassword/?authToken=".$token;
                    $username = $this->input->post('username');
                    $password = $this->input->post('password');
                    $confirmpassword = $this->input->post('confirmpassword');
                    $partnerInfo = array('userName'=>$username ,'password'=> $password,'newPassword'=> $confirmpassword);
                    $senddata = json_encode($partnerInfo);
                }
                $token = $this->session->userdata['ResetDetails']['resetpwdtoken'];
                if($token!=''){
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $apiurl,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $senddata,
                        CURLOPT_HTTPHEADER => array(
                            "Content-Type: application/json"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);

                    curl_close($curl);

                    if ($err) {
                        $data['error'] = $err;
                    } else {
                        $respe = json_decode($response);					
                        $errmsg = $respe->message;

                        if($errmsg!=''){
                            $data['error'] = $respe->message;
                        }

                        if($respe->statusMessage!=''){						
                            $data['success']=$respe->statusMessage;						
                        }
                    }
                }else{
                    $data['error']='Reset Pasword token Expired.';	
                }
            }
            catch (Exception $e)
            {
                $data['error']=$e;
            }		
        }            
        $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
    }
    
    /* Dashboard : getloyaltyprograminfo Program API and fetchUserRewards API call */
     public function dashboard()
    {
        
        $data = array();
        $this->App->checkCustomerAuthenticate();
        $data['main']='customer/dashboard';
        $data['title']='Rewards2pay dashboard';
        $data['metadescription']='';
        $data['metakeyword']='';
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
         if($accessToken==''){
             $message = $this->App->authgenerate();
            if($message=='success'){
                 $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               // $err = $accessToken;	
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];        
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
        
        if($flag==true){          
            $apiurl = base_url().'restapi/getfileresponsebyclient?filename=allprogramlist.json';
            $datas = array('filename'=>"allprogramlist.json");
            $senddata = json_encode($datas);
            
            $apiurl1 = $this->config->item('api_url');
            $apiurl1 = $apiurl1.'getfileresponse?filename=userprogramlistmy.json';
            $datas1 = array('filename'=>"userprogramlistmy.json");
        }
        else{
            
            $apiurl = $this->config->item('api_url');
            $apiurl  = $apiurl.'getloyaltyprograminfo/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);         
            $senddata = json_encode($partnerInfo);            
                        
            $apiurl1 = $this->config->item('api_url');
            $apiurl1  = $apiurl1.'fetchUserRewards/';
            $partnerInfo1 = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials1 = array('userName'=>$username ,'userToken'=>$userToken);
            $merge1 = array('partnerInfo'=>$partnerInfo1,'credentials'=>$credentials1);
            $senddata1 = json_encode($merge1);
        }      
        
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data['error']=$err;
        } else {
          if(!empty($response)){
            $respe = json_decode($response); 
          }              
        }
        
        // -- for get perticular user  program
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl1,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata1,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "access-token: ".$accessToken
            ),
        ));

        $responses = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            $data['error']=$err;
        } else {
            if(!empty($responses)){
                $respes = json_decode($responses); 
            }              
        }
        
        include 'barcode.php';  
        $data['generator'] = new barcode_generator();
        $data['success'] = $this->arrayMerge($respe, $respes);
        
        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data);
    }
    
    /* Mearge two array */
    public function arrayMerge($first,$second)
    {
        $new = array();
        foreach($first as $key => $value){
            foreach($second as $value2){  
                if($value->progId === $value2->progId){  
                    $new[] = array(
                        'progId'=>$value2->progId,
                        'programName'=>$value2->programName,
                        'pointBalance'=>$value2->pointBalance,
                        'pointBalance1'=>$value2->pointBalance1,
                        'pointsSoftBalance'=>$value2->pointsSoftBalance,
                        'lastUpdated'=>$value2->lastUpdated,
                        'active'=>$value2->active,
                        'canRedeem'=>$first[$key]->canRedeem,
                        'minimumBalance'=>$first[$key]->minPointsEntered,
                        'canBarcodeStandard'=>$first[$key]->barcodeStandard,
                        'cashBalance'=>$value2->cashBalance,
                        'cardNumber'=>$value2->cardNumber                       
                    );
                }               
            }
        }
        return $new;
    }
    
    /* GetuserProfile API call */
    public function profile()
    {
        $data = array();
        $this->App->checkCustomerAuthenticate();
        $data['main']='customer/profile';
        $data['title']='Rewards2pay Profile';
        $data['metadescription']='';
        $data['metakeyword']='';
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
         if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];        
        		
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
        if($flag==true){
            $apiurl = $apiurl.'getfileresponse?filename=getuserprofile.json';
            $datas = array('filename'=>"getuserprofile.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $apiurl.'getUserProfile/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);
        }
        
        $curl = curl_init();
        $appurl = $this->config->item('app_url');
        curl_setopt_array($curl, array(        
            CURLOPT_URL => $apiurl,       
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                  "Content-Type: application/json",
                  "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            $data['error'] = $err;
        } else {
            $respe = json_decode($response);					
            $errmsg = $respe->message;
            if($errmsg!=''){
                $data['error'] = $respe->message;
            }

            if($respe->firstName!=''){
                $arraydata = array(
                    'id' => $respe->id,
                    'lastUpdate' =>  $respe->lastUpdate,
                    'lastUpdatedBy' =>  $respe->lastUpdatedBy,
                    'firstName' => $respe->firstName,
                    'lastName' =>  $respe->lastName,
                    'address' =>  $respe->address,
                    'phone' => $respe->phone,
                    'userEmail' =>  $respe->userEmail,
                    'altPhone' =>  $respe->altPhone,
                    'zipCode' => $respe->zipCode,
                    'city' =>  $respe->city,
                    'dob' =>  $respe->dob,
                    'userToken' => $respe->userToken,
                    'tokenCreated' =>  $respe->tokenCreated,
                    'status' =>  $respe->status,
                    'resetCount' => $respe->resetCount
                );                
                $this->session->set_userdata('customerprofiles', $arraydata);
                
                $walletbal = $respe->wallet->walletBalance;
                $softWalletBalance = $respe->wallet->softWalletBalance;
                $estimatedWalletValue = $respe->wallet->estimatedWalletValue;
                $walletdata = array(
                    'walletbalance' =>  $walletbal,
                    'softWalletBalance' =>  $softWalletBalance,
                    'estimatedWalletValue' =>  $estimatedWalletValue,
                );
                $this->session->set_userdata('walletCustomerDetails', $walletdata);
            }
        }

        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data);
    }
   
    /* Logout API Call */
    public function logout()
    {
        $this->App->checkCustomerAuthenticate();
        $token = $this->session->userdata['customerDetails']['userToken'];
        $name = $this->session->userdata['customerDetails']['firstName'].' '.$this->session->userdata['customerDetails']['lastName'];

        $log = array(
            'userToken' => $token,
            'name' => $name,
            'time' => date('Y-m-d H:i A'),
            'IP Address'=>$this->input->server('REMOTE_ADDR'),
        );
        $log=json_encode($log);
        log_message('customerlogout', "Customer Logout : ".$log);
        
        $username = $this->session->userdata['customerDetails']['username'];
        $token = $this->session->userdata['customerDetails']['userToken'];

        $apiurl = $this->config->item('api_url');
        $apiurl = $apiurl.'getfileresponse?filename=logoutvalid.json';

        $flag = $this->config->item('usedstaticdata');
        if($flag==true){				
            $datas = array('filename'=>"logoutvalid.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $this->config->item('api_url');
            $apiurl=$apiurl.'logoutUser/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$password);	
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);
            $appurl = $this->config->item('app_url');
        }
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
           
        } else {
            $respe = json_decode($response);					
            $errmsg = $respe->message;
            if($respe->statusMessage!=''){
                echo $respe->statusMessage;
            }
        }
        
        $this->session->unset_userdata('customerDetails'); 
        $this->session->unset_userdata('customerprofiles'); 
        $this->session->unset_userdata('authDetails');
        redirect('sign-in');
    }
    
    /* Update User Profile API Call */
    public function updateprofile()
    {
        $this->App->checkCustomerAuthenticate();
        $data['main']='customer/profile';
        $data['title']='Rewards2pay Profile';
        $data['metadescription']='';
        $data['metakeyword']='';

        $this->form_validation->set_rules('address', 'Address', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('province', 'Province', 'required');
        $this->form_validation->set_rules('phone', 'Phone number', 'required|min_length[10]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($_POST){
            $accessToken = $this->session->userdata['authDetails']['accessToken'];
            if($accessToken==''){
                $message = $this->App->authgenerate();
                if($message=='success'){
                    $accessToken = $this->session->userdata['authDetails']['accessToken'];
                }else {
                    $err = 'You are not  authenticated. Try again later';	
                }
            }			
        }

        if ($this->form_validation->run() == FALSE || $err != '') {
            if (validation_errors() != '' || $err != '') {
                $data['error'] = validation_errors().$err;
            }
        } else {
            try {
                $firstname = $this->input->post('firstname');
                $lastname = $this->input->post('lastname');
                $address = $this->input->post('address');
                $phone = $this->input->post('phone');
                $email = $this->input->post('email');
                $zipcode = trim($this->input->post('zipcode'));
                $dob = $this->input->post('dob');
                $phone = str_replace("-","",$phone);
		$phone = str_replace(" ","",$phone);

                $username = $this->session->userdata['customerDetails']['username'];
                $userToken = $this->session->userdata['customerDetails']['userToken'];                
                		
                $apiurl = $this->config->item('api_url');
		$flag = $this->config->item('usedstaticdata');
		if($flag==true){
                    $apiurl = $apiurl.'getfileresponse?filename=updateprofilevalid.json';
                    $datas = array('filename'=>"updateprofilevalid.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl = $apiurl.'updateuser/';
                    $partnerId =$this->config->item('partnerId');
                    $partnerName =$this->config->item('partnerName');
                
                    $zipcode = trim($this->input->post('zipcode'));
                    $province = $this->input->post('province');
                    $country = $this->input->post('country');
                    $city = $this->input->post('city');

                    $newaddress = $address.' | '.$city.' | '.$province.'|'.$zipcode.' | '.$country;                
                
                    $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                    $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                    $userDetails = array(
                        'firstName'=>$firstname,
                        'lastName'=>$lastname,
                        'address'=>$newaddress,
                        'phone'=>$phone,
                        'userEmail'=>$email,
                        'zipCode'=>$zipcode,
                        'dob'=>$dob,
                    );
                    $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'userDetails'=>$userDetails);
                    $senddata = json_encode($merge);
                    $accessToken = $this->session->userdata['authDetails']['accessToken'];
                    $appurl = $this->config->item('app_url');
                }

                
                $curl = curl_init();
                curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json",
                    "access-token: ".$accessToken
                ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);

                curl_close($curl);
                if ($err) {
                    $response = json_decode($response);
                    $status = $response->error;
                    $error = $response->message;
                    $data['error'] = $err.' ' .$error;
                } else {
                    $response = json_decode($response);
                    $status = $response->statusCode;
                    $eoor = $response->message;
                    if($eoor!=''){
                        $data['error'] = 'User must login to continue.';
                    }
                    $data['success'] = $response->statusMessage;
                    //---- get profile --------
                    
                    $apiurl = $this->config->item('api_url');
                    $flag = $this->config->item('usedstaticdata');
                    
                    if($flag==true){
                        $apiurl = $apiurl.'getfileresponse?filename=getuserprofile.json';
                        $datas = array('filename'=>"getuserprofile.json");
                        $senddata = json_encode($datas);
                    }
                    else{
                        $apiurl = $apiurl.'getUserProfile/';
                        $username = $this->session->userdata['customerDetails']['username'];
                        $userToken = $this->session->userdata['customerDetails']['userToken'];
                        $partnerId =$this->config->item('partnerId');
                        $partnerName =$this->config->item('partnerName');
                        $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                        $credentials = array('userName'=>$username ,'userToken'=>$userToken);
                        $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
                        $senddata = json_encode($merge);
                        $appurl = $this->config->item('app_url');
                    }
                    
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $apiurl,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $senddata,
                        CURLOPT_HTTPHEADER => array(
                            "Content-Type: application/json",
                            "access-token: ".$accessToken
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);
                    if ($err) {
                        $data['error'] = $err;
                    } else {
                        $respe = json_decode($response);					
                        $errmsg = $respe->message;

                        if($errmsg!=''){
                        $data['error'] = $respe->message;
                        }

                        if($respe->firstName!=''){
                            $arraydata = array(
                                'id' => $respe->id,
                                'lastUpdate' =>  $respe->lastUpdate,
                                'lastUpdatedBy' =>  $respe->lastUpdatedBy,
                                'firstName' => $respe->firstName,
                                'lastName' =>  $respe->lastName,
                                'address' =>  $respe->address,
                                'phone' => $respe->phone,
                                'userEmail' =>  $respe->userEmail,
                                'altPhone' =>  $respe->altPhone,
                                'zipCode' => $respe->zipCode,
                                'city' =>  $respe->city,
                                'dob' =>  $respe->dob,
                                'userToken' => $respe->userToken,
                                'tokenCreated' =>  $respe->tokenCreated,
                                'status' =>  $respe->status,
                                'resetCount' => $respe->resetCount
                            );                
                            $this->session->set_userdata('customerprofiles', $arraydata);
                            
                            $walletbal = $respe->wallet->walletBalance;
                            $softWalletBalance = $respe->wallet->softWalletBalance;
                            $estimatedWalletValue = $respe->wallet->estimatedWalletValue;
                            $walletdata = array(
                                'walletbalance' =>  $walletbal,
                                'softWalletBalance' =>  $softWalletBalance,
                                'estimatedWalletValue' =>  $estimatedWalletValue,
                            );
                            $this->session->set_userdata('walletCustomerDetails', $walletdata);
                        }
                    }
                }
            }
            catch (Exception $e)
            {
                $data['error']=$e;
            }

        }
        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data);
    }
	
    /* Change Password API Call */
    public function changepassword()
    {
        $this->App->checkCustomerAuthenticate();
        $data = array();
        $data['main']='customer/changepassword';
        $data['title']='Rewards2pay change Password';
        $data['metadescription']='';
        $data['metakeyword']='';

        try {            
            $apiurl = $this->config->item('api_url');
            $flag = $this->config->item('usedstaticdata');
            if($flag==true){
                $apiurl = $apiurl.'getfileresponse?filename=resetapiresponse.json';
                $datas = array('filename'=>"resetapiresponse.json");
                $senddata = json_encode($datas);
            }
            else{
                $apiurl=$apiurl.'resetPassword/';
                $username = $this->session->userdata['customerDetails']['username'];
                $credentials = array('userName'=>$username);
                $senddata = json_encode($credentials);
            }            

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);

            if ($err) {
                $data['error']=$err;
            } else {
                $respe = json_decode($response);					
                $resetToken = $respe->userToken;                
                if($resetToken!=''){
                    $arraydata = array(
                        'resetpwdtoken' =>  $resetToken
                    );
                    $this->session->set_userdata('ResetDetails', $arraydata);
                    redirect('user/updatepassword');
                }else {
                    if($respe->message!=''){
                        $data['error']='Information provided to reset password is invalid';	
                    }
                }
            }
        }
        catch (Exception $e)
        {
            $data['error']=$e;
        }

        $this->load->vars($data);
        $this->load->view('customer/templates/inner',$data);
    }
    
    /*  Update Password API Call */
    public function updatepassword()
    {
        $this->App->checkCustomerAuthenticate();
        $data = array();
        $data['main']='customer/changepassword';
        $data['title']='Rewards2pay change Password';
        $data['metadescription']='';
        $data['metakeyword']='';
        $this->form_validation->set_rules('oldpassword', 'Old Password', 'required');
        $this->form_validation->set_rules('password', 'New Password', 'required');
        $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'required|matches[password]');
        
        if($_POST){
            $accessToken = $this->session->userdata['authDetails']['accessToken'];
            if($accessToken==''){
                $message = $this->App->authgenerate();
                if($message=='success'){
                    $accessToken = $this->session->userdata['authDetails']['accessToken'];
                }else {
                    $err = 'You are not  authenticated. Try again later';	
                }                
                $password = $this->input->post('password');
                $jk = $this->App->password_strength_check($password);                
                if ($jk == '0') {
                    $err1 = 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
                }
            }
            $oldpwd = $this->session->userdata['customerDetails']['oldpassword'];
            $oldpassword=$this->input->post('oldpassword');
            if($oldpwd!=$oldpassword){
                $err2 = 'Old Password does not matched.';
            }
        }
		
        if ($this->form_validation->run() == FALSE || $err!='' || $err1!='' || $err2!='') {
            if (validation_errors() != '' || $err!='' || $err1!='' || $err2!='') {
                $data['error'] = validation_errors().$err.$err1.$err2; 
            }
        } else {	
            try {
                $token = $this->session->userdata['ResetDetails']['resetpwdtoken'];                    
                $apiurl = $this->config->item('api_url');
		$flag = $this->config->item('usedstaticdata');
                
		if($flag==true){	
                    $apiurl = $apiurl.'getfileresponse?filename=updatepasswordresponse.json';
                    $datas = array('filename'=>"updatepasswordresponse.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl = $this->config->item('api_url');
                    $apiurl=$apiurl."updatePassword/?authToken=".$token;
                    $username = $this->session->userdata['customerDetails']['username'];
                    $password = $this->input->post('password');
                    $confirmpassword = $this->input->post('confirmpassword');

                    $partnerInfo = array('userName'=>$username ,'password'=> $password,'newPassword'=> $confirmpassword);
                    $senddata = json_encode($partnerInfo);
                }
                    if($token!=''){
                        $curl = curl_init();
                        curl_setopt_array($curl, array(
                            CURLOPT_URL => $apiurl,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => "",
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 30,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => "POST",
                            CURLOPT_POSTFIELDS => $senddata,
                            CURLOPT_HTTPHEADER => array(
                                "Content-Type: application/json"
                            ),
                        ));

                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                        curl_close($curl);
                        if ($err) {
                          $data['error'] = $err;
                        } else {
                            $respe = json_decode($response);				
                            $errmsg = $respe->message;                            
                            if($errmsg!=''){
                                $data['error'] = $respe->message;
                            }
                            if($respe->statusMessage!=''){						
                                $data['success']=$respe->statusMessage;				
                                $apiurl = $this->config->item('api_url');
                                $flag = $this->config->item('usedstaticdata');
                                if($flag==true){
                                    $apiurl = $apiurl.'getfileresponse?filename=loginsuccessapi.json';
                                    $datas = array('filename'=>"loginsuccessapi.json");
                                    $senddata = json_encode($datas);
                                }
                                else{
                                    $apiurl=$apiurl.'loginuser/';
                                    $partnerId =$this->config->item('partnerId');
                                    $partnerName =$this->config->item('partnerName');
                                    $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
                                    $credentials = array('userName'=>$username ,'newPassword'=>$password);	
                                    $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
                                    $senddata = json_encode($merge);
                                }                                
                                
                                $curl = curl_init();
                                curl_setopt_array($curl, array(
                                CURLOPT_URL => $apiurl,
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_ENCODING => "",
                                CURLOPT_MAXREDIRS => 10,
                                CURLOPT_TIMEOUT => 30,
                                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                CURLOPT_CUSTOMREQUEST => "POST",
                                CURLOPT_POSTFIELDS => $senddata,
                                CURLOPT_HTTPHEADER => array(
                                "Content-Type: application/json",
                                "access_token: ".$accessToken
                                ),
                                ));

                                $response = curl_exec($curl);
                                $err = curl_error($curl);
                                $respe = json_decode($response);					
                                $errmsg = $respe->message;
                                $arraydata = array(
                                    'id' => $respe->id,
                                    'lastUpdate' =>  $respe->lastUpdate,
                                    'lastUpdatedBy' =>  $respe->lastUpdatedBy,
                                    'firstName' => $respe->firstName,
                                    'lastName' =>  $respe->lastName,
                                    'address' =>  $respe->address,
                                    'phone' => $respe->phone,
                                    'userEmail' =>  $respe->userEmail,
                                    'altPhone' =>  $respe->altPhone,
                                    'zipCode' => $respe->zipCode,
                                    'city' =>  $respe->city,
                                    'dob' =>  $respe->dob,
                                    'userToken' => $respe->userToken,
                                    'tokenCreated' =>  $respe->tokenCreated,
                                    'status' =>  $respe->status,
                                    'resetCount' => $respe->resetCount,
                                    'username' => $username,
                                    'oldpassword'=>$password
                                );                
                                $this->session->set_userdata('customerDetails', $arraydata);
                                
                                $walletbal = $respe->wallet->walletBalance;
                                $softWalletBalance = $respe->wallet->softWalletBalance;
                                $estimatedWalletValue = $respe->wallet->estimatedWalletValue;

                                $walletdata = array(
                                    'walletbalance' =>  $walletbal,
                                    'softWalletBalance' =>  $softWalletBalance,
                                    'estimatedWalletValue' =>  $estimatedWalletValue,
                                );
                                $this->session->set_userdata('walletCustomerDetails', $walletdata);
                                
                            }else{
                                $errmsg = $respe->message;
                                $data['error'] = $respe->message;
                            }
                        }
                    }else{
                        $data['error']='Change Password token Expired.';	
                    }
                }                
                catch (Exception $e)
                {
                    $data['error']=$e;
                }	
        }
		$this->load->vars($data);
		$this->load->view('customer/templates/inner',$data);
	}
    
    
   /* Update Password API Call when send forgot password mail */
   public function updateresetPassword($username='',$token='')
   {        
        $data['main']='front/useraccess/resetpasswordregister';
        $data['title']='Rewards2pay Reset Password';
        $data['metadescription']='';
        $data['metakeyword']='';
        $data['username']=$username;
        $data['token']=$token;

        $this->form_validation->set_rules('username', 'User Name', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('confirmpassword', 'Confirm Password', 'required|matches[password]');
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
               
            }
        }
        if($_POST){                
            $password = $this->input->post('confirmpassword');
            $jk = $this->App->password_strength_check($password);                
            if ($jk == '0') {
                $err1 = 'Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.';
            }
        }			
        
        
	if ($this->form_validation->run() == FALSE || $err!='' || $err1!='') {
            if (validation_errors() != '' || $err!='' || $err1!='') {
                $data['error'] = validation_errors().$err.$err1;               
            }
        } else {	
            try {
                $username = $this->input->post('username');
                $password = $this->input->post('password');
                $confirmpassword = $this->input->post('confirmpassword');              
                $apiurl = $this->config->item('api_url');		
                
		$flag = $this->config->item('usedstaticdata');
		if($flag==true){	
                    $apiurl = $apiurl.'getfileresponse?filename=updatepasswordresponse.json';
                    $datas = array('filename'=>"updatepasswordresponse.json");
                    $senddata = json_encode($datas);
		}
		else{
                    $apiurl=$apiurl."updatePassword/?authToken=".$token;                    
                    $partnerInfo = array('userName'=>$username ,'password'=> $password,'newPassword'=> $confirmpassword);
                    $senddata = json_encode($partnerInfo);
                    $token = $token;  
                }
                
                if($token!=''){
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => $apiurl,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => $senddata,
                        CURLOPT_HTTPHEADER => array(
                            "Content-Type: application/json"
                        ),
                    ));

                    $response = curl_exec($curl);
                    $err = curl_error($curl);
                    curl_close($curl);

                    if ($err) {
                            $data['error']='Reset Password token Expired.';
                    } else {
                            $respe = json_decode($response);                   				
                            $errmsg = $respe->message;
                       if($errmsg!=''){		
                            $data['error'] = $respe->message;
                            $this->session->set_flashdata('error', $respe->message);
                            redirect('sign-in');
                       }
                       if($respe->statusMessage!=''){		
                            $data['success'] = $respe->statusMessage;
                            $this->session->set_flashdata('success', 'Reset Password Successfully Please Login & Continue..');
                            redirect('sign-in');
                       }
                    }
                }else{
                    $this->session->set_flashdata('error', 'Reset Password token Expired.');
                    redirect('sign-in');
                }
            }
            catch (Exception $e)
            {
                $data['error']=$e;
            }		
        }            
        $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
   }
   
    /* Active user API Call */
    public function activateUser($username='',$token='')
    {
        $data = array();
        $data['main']='front/useraccess/activelogin';
        $data['title']='Rewards2pay Activate Account';
        $data['metadescription']='';
        $data['metakeyword']='';
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                $accessToken = 'MWRdkva6AFS2143Lp2qblwNRpSuA';	
            }
        }
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
               
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
        if($flag==true){	
             $apiurl = $apiurl.'getfileresponse?filename=authresponse.json';
            $datas = array('filename'=>"authresponse.json");
            $senddata = json_encode($datas);
        }
        else{
            $apiurl = $apiurl."activateuser/";
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username,'userToken'=>$token);	
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials);
            $senddata = json_encode($merge);
        }
        $curl = curl_init();
          curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
              "Content-Type: application/json",
              "header-name: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);        
        curl_close($curl);
        if ($err) {
            $data['error']='Activation Url Token Expired.';
        } else {
            $respe = json_decode($response);                   				
            $errmsg = $respe->message;
            if($errmsg!=''){
                $data['error']=$errmsg;
            }
            if($respe->statusCode=='1'){
                $data['success']=$respe->statusMessage;
            }if($respe->statusCode=='0'){
                $data['error']=$respe->statusMessage;
            }            
        }
        $this->load->vars($data);
	$this->load->view('customer/templates/master',$data);
   }

}
