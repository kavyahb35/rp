<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paypal extends CI_Controller {	
    public function __construct()
    {
        parent::__construct();
        $this->load->model('App');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('paypal_lib');
    }
    
    /* Call Paypal */
    function buy()
    {
        // Set variables for paypal form
        $returnURL = base_url().'paypal/success'; //payment success url
        $cancelURL = base_url().'paypal/cancel'; //payment cancel url
        $notifyURL = base_url().'paypal/ipn'; //ipn url
        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                $err = 'You are not  authenticated. Try again later';	
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];    
        
       
        $userID = $userToken;
        $prodname = $username;
        $itemid = $userToken;
        $price = $this->input->post('balanceval');
        
        // Add fields to paypal form
        $this->paypal_lib->add_field('return', $returnURL);
        $this->paypal_lib->add_field('cancel_return', $cancelURL);
        $this->paypal_lib->add_field('notify_url', $notifyURL);
        $this->paypal_lib->add_field('item_name', $prodname);
        $this->paypal_lib->add_field('custom', $userID);
        $this->paypal_lib->add_field('item_number',  $itemid);
        $this->paypal_lib->add_field('amount',  $price);
        
        // Load paypal form
        $this->paypal_lib->paypal_auto_form();
    }
    
    /* Call success payment method */
    function success()
    {
        // Get the transaction paypal data
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                $err = 'You are not  authenticated. Try again later';	
            }
        }
        
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken']; 
        
        $data = array();
        $data['main']='paypal/success';
        $data['title']='Rewards2pay success payment';
        $data['metadescription']='';
        $data['metakeyword']='';
        
          $arra= array(
            'payer_email' =>$_REQUEST['payer_email'],
            'payer_id' =>$_REQUEST['payer_id'],
            'payer_status' =>$_REQUEST['payer_status'],
            'last_name' =>$_REQUEST['last_name'],
            'address_name' =>$_REQUEST['address_name'],
            'address_street' =>$_REQUEST['address_street'],
            'address_city' =>$_REQUEST['address_city'],
            'address_state' =>$_REQUEST['address_state'],
            'address_country_code' =>$_REQUEST['address_country_code'],
            'residence_country' =>$_REQUEST['residence_country'],
             'txn_id' =>$_REQUEST['txn_id'],
            'mc_gross' =>$_REQUEST['mc_gross'],
            'payment_status' =>$_REQUEST['payment_status'],
            'txn_type' =>$_REQUEST['txn_type'],
            'payment_date' =>$_REQUEST['payment_date'],
            'receiver_id' =>$_REQUEST['receiver_id'],
            'business' =>$_REQUEST['business'],
            'verify_sign' =>$_REQUEST['verify_sign']            
        );
        $this->session->set_userdata('payoutSession', $arra);
        
        $data['item_number'] = $paypalInfo['item_number']; 
        $data['txn_id'] = $_REQUEST['txn_id'];
        $data['payment_amt'] = $_REQUEST['mc_gross'];
        $data['currency_code'] = $_REQUEST["mc_currency"];
        $data['status'] = $_REQUEST['payment_status'];
        
        // Pass the transaction data to view
        $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
    }
    
    /* Call cancel payment */
    function cancel()
    {
	$data['main']='paypal/cancel';
        $data['title']='Rewards2pay cancel payment';
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                $err = 'You are not  authenticated. Try again later';	
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];  
         $this->load->vars($data);
        $this->load->view('customer/templates/master',$data);
     }
     
    function ipn()
    {        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message == 'success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } else {
                $err = 'You are not  authenticated. Try again later';	
            }
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];   
        $paypalInfo = $this->input->post();

        $data['user_id'] = $paypalInfo['custom'];
        $data['product_id'] = $paypalInfo["item_number"];
        $data['txn_id'] = $paypalInfo["txn_id"];
        $data['payment_gross'] = $paypalInfo["mc_gross"];
        $data['currency_code'] = $paypalInfo["mc_currency"];
        $data['payer_email'] = $paypalInfo["payer_email"];
        $data['payment_status'] = $paypalInfo["payment_status"];
       
        $paypalURL = $this->paypal_lib->paypal_url;
        $result = $this->paypal_lib->curlPost($paypalURL,$paypalInfo);
        
        if(preg_match("/VERIFIED/i",$result)){
        }
    }
    
    /* After payment successfull call function */
    function accessprocess()
    {
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        if($accessToken==''){
            $message = $this->App->authgenerate();
            if($message=='success'){
                $accessToken = $this->session->userdata['authDetails']['accessToken'];
            } 
        }
        $username = $this->session->userdata['customerDetails']['username'];
        $userToken = $this->session->userdata['customerDetails']['userToken'];         
        $payer_email = $this->session->userdata['payoutSession']['payer_email'];
        $payer_id = $this->session->userdata['payoutSession']['payer_id'];
        $payer_status = $this->session->userdata['payoutSession']['payer_status'];
        $last_name = $this->session->userdata['payoutSession']['last_name'];
        $address_name = $this->session->userdata['payoutSession']['address_name'];
        $address_street = $this->session->userdata['payoutSession']['address_street'];              
        $address_city = $this->session->userdata['payoutSession']['address_city'];
        $address_state = $this->session->userdata['payoutSession']['address_state'];
        $address_country_code = $this->session->userdata['payoutSession']['address_country_code'];
        $residence_country = $this->session->userdata['payoutSession']['residence_country'];
        $txn_id = $this->session->userdata['payoutSession']['txn_id'];
        $mc_gross = $this->session->userdata['payoutSession']['mc_gross'];
        $payment_status = $this->session->userdata['payoutSession']['payment_status'];
        $txn_type = $this->session->userdata['payoutSession']['txn_type'];
        $payment_date = $this->session->userdata['payoutSession']['payment_date'];
        $receiver_id = $this->session->userdata['payoutSession']['receiver_id'];
        $business = $this->session->userdata['payoutSession']['business'];
        $verify_sign = $this->session->userdata['payoutSession']['verify_sign'];
        
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');
         if($flag==true){
            $apiurl = $apiurl.'getfileresponse?filename=paypalvalid.json';
            $datas = array('filename'=>"paypalvalid.json");
            $senddata = json_encode($datas);
        }
        else{
            $paypalPayLoad = $payer_email.','.$payer_id.','.$payer_status.','.$last_name.','.$address_name.','.$address_street.','.$address_city.','.$address_state.','.$address_country_code.','.$residence_country.','.$txn_id.','.$mc_gross.','.$payment_status.','.$txn_type.','.$payment_date.','.$receiver_id.','.$business.','.$verify_sign;
            $cash = $mc_gross;
            $paymentId = $txn_id;
            
            $apiurl = $this->config->item('api_url');
            $apiurl = $apiurl.'confirmwalletcashredemption/';
            $partnerId =$this->config->item('partnerId');
            $partnerName =$this->config->item('partnerName');
            
            $partnerInfo = array('partnerId'=>$partnerId ,'name'=> $partnerName);
            $credentials = array('userName'=>$username ,'userToken'=>$userToken);
            $rewardsProgramInfo = array('paymentId'=>$paymentId , 'cash'=>$cash , 'paypalPayLoad'=>$paypalPayLoad);
            
            $merge = array('partnerInfo'=>$partnerInfo,'credentials'=>$credentials,'rewardPointsData'=>$rewardsProgramInfo);
            $senddata = json_encode($merge);
        }     
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiurl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $senddata,
            CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "access-token: ".$accessToken
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
         redirect('paypal/cancel');
        } else {
          if(!empty($response)){
            $respe = json_decode($response);
            if($respe->statusCode =='1'){
                redirect('dashboard');
            }else{
                $message = $respe->message;
                $this->session->set_flashdata('paypalerror', $respe->message);				 
                redirect('paypal/cancel');
            }             
          }              
        }        
    }    
}
