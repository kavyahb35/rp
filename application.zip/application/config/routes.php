<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'front';

/* Customer access routes */
$route['sign-in'] = 'user/login';
$route['login'] = 'user/login';
$route['sign-up'] = 'user/register';
$route['forgot-password'] = 'user/forgotpassword';
$route['reset-password'] = 'user/resetpassword';
$route['dashboard'] = 'user/dashboard';
$route['front'] = 'front/index';
$route['profile'] = 'user/profile';
$route['logout'] = 'user/logout';
$route['update-profile'] = 'user/updateprofile';
$route['activateUser/(:any)/(:any)'] = 'user/activateUser/$1/$2';
$route['update-password/(:any)/(:any)'] = 'user/updateresetPassword/$1/$2';
$route['manage-cards'] = 'managecards';

/* 404 page not found */
$route['404_override'] = 'page404';
$route['translate_uri_dashes'] = FALSE;
