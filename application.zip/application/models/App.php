<?php
class App extends CI_Model
{
    function __construct()
    {
        parent::__construct();        
        $this->transTable = 'payments';
    }
    /* Insert contact details in database */
    public function insertdata($tblname, $array)
    {
        $this->db->insert($tblname, $array);
        return $this->db->insert_id();
    }   
    
    /* Check User authentication */
    public function checkCustomerAuthenticate()
    {
        $Id = $this->session->userdata['customerDetails']['userToken'];        
        $authId = $this->session->userdata['authDetails']['accessToken'];
        if ($Id == '') {
            redirect('sign-in');            
        } else {
            if ($authId == '') {
                $this->authgenerate();
            }
        }
    }
   
    /* Check Password strength */
    public function password_strength_check($password, $min_len = 8, $max_len = 70, $req_digit = 1, $req_lower = 1, $req_upper = 1, $req_symbol = 1)
    {
        $regex = '/^';
        if ($req_digit > 0) {
            $regex .= '(?=.*\d)';
        }
        if ($req_lower > 0) {
            $regex .= '(?=.*[a-z])';
        }
        if ($req_upper > 0) {
            $regex .= '(?=.*[A-Z])';
        }
        if ($req_symbol > 0) {
            $regex .= '(?=.*[^a-zA-Z\d])';
        }
        $regex .= '.{' . $min_len . ',' . $max_len . '}$/';
        
        if (preg_match($regex, $password)) {
            return 1;
        } else {
            return 0;
        }
    }
    
   /* Authentication API Call */      
    function authgenerate()
    {        
        $accessToken = $this->session->userdata['authDetails']['accessToken'];
        $apiurl = $this->config->item('api_url');
        $flag = $this->config->item('usedstaticdata');        
        
        if ($accessToken == '') {            
            if ($flag == true) {
                $apiurl   = $apiurl.'getfileresponse?filename=authtoken.json';
                $datas    = array(
                    'filename' => "authtoken.json"
                );
                $senddata = json_encode($datas);
            } else {
                $apiurl   = $apiurl . "oauth/client_credential/accesstoken?grant_type=client_credentials";
                $senddata = $this->config->item('authenticationSendData');
            }
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $apiurl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => $senddata,
                CURLOPT_HTTPHEADER => array(
                    "Content-Type: application/x-www-form-urlencoded"
                )
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);            
            curl_close($curl);
            
            if ($err) {
                $path = base_url('fakedb/authtoken.json');
                $str = file_get_contents($path);
                $respe = json_decode($str, true);
                $arraydata = array(
                    'accessToken' => $respe['access_token'],
                    'status' => $response['status'],
                    'client_id' => $response['client_id']
                );
                $this->session->set_userdata('authDetails', $arraydata);
                
            } else {
                $data = 'success';
                $response = json_decode($response);
                $arraydata = array(
                    'accessToken' => $response->access_token,
                    'status' => $response->status,
                    'client_id' => $response->client_id
                );                
                $this->session->set_userdata('authDetails', $arraydata);
                return $data;
            }
        }
    }
    
    /* Check username strength */
    function username_strength_check($password, $min_len = 7, $max_len = 70, $req_digit = 1, $req_lower = 1, $req_upper = 1, $req_symbol = 1)
    {
        $regex = '/^';
        if ($req_digit > 0) {
            $regex .= '(?=.*\d)';
        }
        if ($req_lower > 0) {
            $regex .= '(?=.*[a-z])';
        }        
        $regex .= '.{' . $min_len . ',' . $max_len . '}$/';        
        if (preg_match($regex, $password)) {
            return 1;
        } else {
            return 0;
        }
    }
   
}