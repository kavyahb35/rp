<?php $this->load->view('front/homepart/header');?>
<div class="content-wrapper">
   <div class="content-body">
      <main>
         <!-- Header: 3D Graphics -->
         <section class="head-area" id="head-area" data-midnight="white">
            <div id="particles-js"></div>
            <div class="head-content container-fluid bg-gradient d-flex align-items-center">
               <div class="container">
                  <div class="banner-wrapper">
                     <div class="row align-items-center">
                        <div class="col-lg-6 col-md-12">
                           <div class="banner-content pt-5">
                              <h1 class="best-template animated bh1" data-animation="fadeInUpShorter" data-animation-delay="1.5s">Untap the hidden value in your wallet and encash your loyalty points. <br class="d-none d-xl-block"> Now your Points/Miles = Cash </h1>
                              <h3 class="mb-4 d-block white animated" data-animation="fadeInUpShorter" data-animation-delay="1.6s">Redeem your Loyalty Points/miles and get Cash in exchange.  <br class="d-none d-xl-block"> Don't rely on expensive options to exchange your points anymore.</h3>
                              <div class="mt-5">
                                 <a href="<?php echo base_url('sign-in');?>" class="btn btn-lg btn-gradient-purple btn-glow mr-2 animated" data-animation="fadeInUpShorter" data-animation-delay="1.7s">Sign In</a>
                                 <a href="#about" class="btn btn-lg btn-gradient-purple btn-glow animated" data-animation="fadeInUpShorter" data-animation-delay="1.8s">About Us</a>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-6 col-md-12 move-first">
                           <div class="crypto-3d-graphic animated" data-animation="fadeInUpShorter" data-animation-delay="1.7s">
                              <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/Untitled-21.png" class="graphic-3d-img mx-auto d-block homeslideimg" alt="R2P">
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--/ Header: 3D Graphics -->
         <!-- Exchange Listing Area -->
         <section class="exchange-listing" id="exchange-listing">
            <!-- Exchange Listing Area Starts -->
            <div class="container-fluid bg-color">
               <div class="container">
                  <div class="row listing list-unstyled">
                     <div class="col d-none d-lg-block text-center animated" data-animation="fadeInUpShorter" data-animation-delay="0.2s">
                        <!--<img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/icon-arrow.png" alt="icon-arrow">-->
                        <i class="fa fa-bullhorn" style="font-size:30px"></i>
                        <p class="grey-accent2 mt-1" style="    font-weight: 700;    color: #000;">Offers :</p>
                     </div>
                     <div class="col text-center animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                        <p class="grey-accent2 mt-1">Digitize Loyalty Points </p>
                     </div>
                     <div class="col text-center animated" data-animation="fadeInUpShorter" data-animation-delay="0.4s">
                        <p class="grey-accent2 mt-1">Monetize your Points/Miles </p>
                     </div>
                     <div class="col text-center animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s">
                        <p class="grey-accent2 mt-1">Consolidate the Cash value </p>
                     </div>
                     <div class="col text-center animated" data-animation="fadeInUpShorter" data-animation-delay="0.6s">
                        <p class="grey-accent2 mt-1">Never miss out an opportunity to earn more Points </p>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Exchange Listing Area Ends -->
         </section>
         <!--/ Exchange Listing Area -->
         <!-- About -->
         <section class="about section-padding" id="about">
            <div class="container-fluid">
               <div class="container">
                  <div class="heading text-center">
                     <div class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                        <h6 class="sub-title">About</h6>
                        <h2 class="title">About</h2>
                     </div>
                     <p class="content-desc animated about-subtitle" data-animation="fadeInUpShorter" data-animation-delay="0.4s">Our aim is to make loyalty points same as liquid as Cash by allowing customers to use points as a payment alternate.
                     </p>
                  </div>
                  <div class="content-area">
                     <div class="row">
                        <div class="col-md-12 col-lg-6 animated" data-animation="fadeInLeftShorter" data-animation-delay="0.5s">
                           <h4 class="title">What is Rewards2pay ?</h4>
                           <p>Rewards2Pay is a Loyalty points processing platform that allows our registered users (“You”) to redeem their Loyalty Points/Miles as use them as Cash.</p>
                           <p>The platform valuates your points and provides you the independence to convert it into cash. Take full control of the redemption process of your Loyalty points.  </p>
                           <p>Store all your Loyalty programs in a bank level secure platform. You manage, monitor and consolidate the value of your points.</p>
                        </div>
                        <div class="col-md-12 col-lg-6 animated" data-animation="fadeInRightShorter" data-animation-delay="0.5s">
                           <div class="position-relative what-is-crypto-img float-xl-right">
                              <img class="img-fluid" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/what-is-crypto.png" alt="What is Crypto?">
                              <div class="play-video text-center">
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--/ About -->
         <!-- Problems & Solutions -->
         <section id="problem-solution" class="problem-solution section-pro section-padding bg-gradient" data-midnight="white">
            <div class="container-fluid">
               <div class="container">
                  <div class="dark-bg-heading text-center">
                     <div class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                        <h6 class="sub-title">Our Platform</h6>
                        <h2 class="title">Why  <strong>Rewards2Pay?</strong></h2>
                     </div>
                  </div>
                  <div class="problems">
                     <div class="row">
                        <div class="col-md-12 col-lg-6">
                           <div class="dark-bg-heading mb-4">
                              <h4 class="title animated" data-animation="fadeInUpShorter" data-animation-delay="0.2s">Problems</h4>
                           </div>
                           <p class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.4s">Canadian have estimated $16 billion worth of unused points due to the inherent nature of the loyalty industry.  </p>
                           <p class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.6s">The Loyalty program provider aims to create brand stickiness and reward their loyal customers and the Customers aim is to maximize redemption value.</p>
                           <p class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.8s">Competing businesses cannot partner their Loyalty programs. Even partnering with competitor’s partner is improbable. So all loyalty points can never come together, making it challenging for customers to manage and redeem points.</p>
                        </div>
                        <div class="col-md-12 col-lg-6 text-center">
                           <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/problems-graphic.png" class="problems-img animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s" alt="problems-graphic">
                        </div>
                     </div>
                  </div>
                  <div class="solutions mt-5">
                     <div class="row">
                        <div class="col-md-12 col-lg-6 text-center">
                           <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/solutions-graphic.png" class="solutions-img animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s" alt="problems-graphic">
                        </div>
                        <div class="col-md-12 col-lg-6 move-first">
                           <div class="dark-bg-heading mb-4">
                              <h4 class="title animated" data-animation="fadeInUpShorter" data-animation-delay="0.2s">Solutions</h4>
                           </div>
                           <p class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s">A platform that can independently and fairly value all loyalty points without impacting the essence of the Loyalty point provider’s points/miles valuation can be easily adopted by all Loyalty customers.  </p>
                           <p class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.7s">Simply consolidate your points on a single platform and if you wish to redeem, simply choose the program and amount of points you wish to encash.  </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--/ Problems & Solutions -->
         <!--/ Advisors -->
         <section id="team" class="advisor team section-padding">
            <div class="container-fluid">
               <div class="container">
                  <div class="heading text-center">
                     <div class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                        <h6 class="sub-title">Our Team</h6>
                        <h2 class="title">Our Team</h2>
                     </div>
                     <p class="content-desc animated" data-animation="fadeInUpShorter" data-animation-delay="0.4s">Lorem Ipsum is simply dummy text of the printing and typesetting industry.  <br class="d-none d-xl-block"> Lorem Ipsum has been the industry's standard dummy text ever since the 1500.</p>
                  </div>
                  <div class="team-profile mt-5">
                     <div class="row mb-5">
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-5 animated" data-animation="flipInX" data-animation-delay="0.5s">
                           <div class="d-flex">
                              <div class="team-img float-left mr-3" data-toggle="modal" data-target="#teamUser1">
                                 <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-3.png" alt="team-profile-1" class="rounded-circle" width="128">
                              </div>
                              <div class="team-icon">
                                 <i class="ti-linkedin"></i>
                              </div>
                              <div class="profile align-self-center">
                                 <div class="name">Nadia Sidko</div>
                                 <div class="role">Blockchain Entrepreneur</div>
                                 <div class="crypto-profile">
                                    <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/company-logo-1.png" alt="Team User">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-5 animated" data-animation="flipInX" data-animation-delay="0.6s">
                           <div class="d-flex">
                              <div class="team-img float-left mr-3" data-toggle="modal" data-target="#teamUser8">
                                 <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-8.png" alt="team-profile-1" class="rounded-circle" width="128">
                              </div>
                              <div class="team-icon">
                                 <i class="ti-linkedin"></i>
                              </div>
                              <div class="profile align-self-center">
                                 <div class="name">Pavel Volek</div>
                                 <div class="role">Entrepreneur and Investor</div>
                                 <div class="crypto-profile">
                                    <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/company-logo-2.png" alt="Team User">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-5 animated" data-animation="flipInX" data-animation-delay="0.7s" data-toggle="modal" data-target="#teamUser3">
                           <div class="d-flex">
                              <div class="team-img float-left mr-3">
                                 <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-3.png" alt="team-profile-1" class="rounded-circle" width="128">
                              </div>
                              <div class="team-icon">
                                 <i class="ti-linkedin"></i>
                              </div>
                              <div class="profile align-self-center">
                                 <div class="name">Alyona Blakytna</div>
                                 <div class="role">Fin-Tech Entrepreneur</div>
                                 <div class="crypto-profile">
                                    <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/company-logo-3.png" alt="Team User">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-5 animated" data-animation="flipInX" data-animation-delay="0.8s" data-toggle="modal" data-target="#teamUser11">
                           <div class="d-flex">
                              <div class="team-img float-left mr-3">
                                 <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-2.png" alt="team-profile-1" class="rounded-circle" width="128">
                              </div>
                              <div class="team-icon">
                                 <i class="ti-linkedin"></i>
                              </div>
                              <div class="profile align-self-center">
                                 <div class="name">Martin Solarik</div>
                                 <div class="role">Fin-Tech Investor</div>
                                 <div class="crypto-profile">
                                    <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/company-logo-4.png" alt="Team User">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-5 animated" data-animation="flipInX" data-animation-delay="0.9s" data-toggle="modal" data-target="#teamUser7">
                           <div class="d-flex">
                              <div class="team-img float-left mr-3">
                                 <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-7.png" alt="team-profile-1" class="rounded-circle" width="128">
                              </div>
                              <div class="team-icon">
                                 <i class="ti-linkedin"></i>
                              </div>
                              <div class="profile align-self-center">
                                 <div class="name">Kate Fisenko</div>
                                 <div class="role">Fin-Tech Investor</div>
                                 <div class="crypto-profile">
                                    <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/company-logo-5.png" alt="Team User">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-4 mb-5 animated" data-animation="flipInX" data-animation-delay="1.0s" data-toggle="modal" data-target="#teamUser12">
                           <div class="d-flex">
                              <div class="team-img float-left mr-3">
                                 <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-12.png" alt="team-profile-1" class="rounded-circle" width="128">
                              </div>
                              <div class="team-icon">
                                 <i class="ti-linkedin"></i>
                              </div>
                              <div class="profile align-self-center">
                                 <div class="name">Michal Krajnansky</div>
                                 <div class="role">Blockchain Entrepreneur</div>
                                 <div class="crypto-profile">
                                    <img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/company-logo-1.png" alt="Team User">
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <!--Advisors -->
         <!--/ FAQ -->
         <section id="faq" class="faq section-padding bg-gradient" data-midnight="white">
            <div class="container-fluid">
               <div class="container">
                  <div class="dark-bg-heading text-center">
                     <div class="animated" data-animation="fadeInUpShorter" data-animation-delay="0.3s">
                        <h6 class="sub-title">question</h6>
                        <h2 class="title">FAQ</h2>
                     </div>
                     <p class="content-desc animated" data-animation="fadeInUpShorter" data-animation-delay="0.4s">Originally the term "FAQ" referred to the Frequently Asked Question itself, and the <br class="d-none d-xl-block">compilation of questions and answers was known as a "FAQ list" or some similar expression.</p>
                  </div>
                  <div class="row">
                     <div class="col">
                        <nav>
                           <div class="nav nav-pills nav-underline mb-5 animated" data-animation="fadeInUpShorter" data-animation-delay="0.5s" id="myTab" role="tablist">
                              <?php if(!empty($faqs)){ $i=1;
                                 foreach($faqs as $faqstit){											  
                                  $title = $faqstit['title'];
                                  $slug = $faqstit['slug']; ?>
                              <a href="#<?php echo $slug;?>" class="nav-item nav-link <?php if($i=='1'){ echo 'active';}?>" id="<?php echo $slug;?>-tab" data-toggle="tab" aria-controls="<?php echo $slug;?>" aria-selected="true" role="tab"><?php echo $title;?></a>
                              <?php
                                 $i++;}
                                 }?>
                           </div>
                        </nav>
                        <div class="tab-content" id="myTabContent">
                           <?php if(!empty($faqs)){ $j=1;
                              foreach($faqs as $faqstit){	 
                               $title = $faqstit['title'];
                               $slug = $faqstit['slug']; 
                                $sections = $faqstit['sections'];
                                 ?>
                           <div class="tab-pane fade show <?php  if($j=='1') { echo 'active';}?>" id="<?php echo $slug;?>" role="tabpanel" aria-labelledby="<?php echo $slug;?>-tab">
                              <div id="<?php echo $slug;?>-accordion" class="collapse-icon accordion-icon-rotate ptagcls">
                                 <?php if(!empty($sections)){ $i=1;
                                    foreach($sections as $sec){
                                    ?>
                                 <?php if($j!='1'){ echo '<div class="card">'; }?>
                                 <?php if($j=='1'){ ?>		
                                 <div class="card animated fadeInUpShorter" data-animation="fadeInUpShorter" data-animation-delay="0.1s" style="animation-delay: 0.1s; opacity: 1;">
                                    <?php }?>
                                    <div class="card-header" <?php if($j=='1'){ ?> id="headingOne" <?php } else { echo 'id="icoHeadingOne"';}?> >
                                       <h5 class="mb-0">
                                          <a class="btn-link" data-toggle="collapse" data-target="#<?php if($j=='1'){ echo 'collapse'.$i;}else{ echo $slug.'collapse'.$i;} ?>" aria-expanded="<?php if($i=='1'){ echo 'true';}else { echo 'false';}?>" aria-controls="<?php if($j=='1'){ echo 'collapse'.$i;}else{ echo $slug.'collapse'.$i;} ?>">
                                          <span class="icon gradient-crypto"></span>
                                          <?php echo $sec['question'];?>
                                          </a>
                                       </h5>
                                    </div>
                                    <div id="<?php if($j=='1'){ echo 'collapse'.$i;}else{ echo $slug.'collapse'.$i;} ?>" class="collapse <?php if($i=='1'){ echo 'show';}?>" aria-labelledby="<?php if($j=='1'){ ?> id="headingOne" <?php } else { echo 'id="icoHeadingOne"';}?>" data-parent="#<?php echo $slug;?>-accordion">
                                    <div class="card-body ptagcls6">
                                       <?php echo $sec['answer'];?> 
                                    </div>
                                 </div>
                                 <?php if($j=='1'){ ?>		
                              </div>
                              <?php }?>
                              <?php if($j!='1'){ echo '</div>'; }?>
                              <?php $i++; }
                                 }?>
                           </div>
                        </div>
                        <?php $j++; }
                           } ?>								
                     </div>
                  </div>
               </div>
            </div>
   </div>
   </section>
   <!--/ FAQ --><?php $this->load->view('front/homepart/contact');?>
    <!-- ICO Video Modal -->
    <div class="modal ico-modal fade" id="ico-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body p-0">
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" id="video"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Dev Team Modal Pop-ups -->
    <!-- teamUser9 -->
    <div class="modal team-modal fade" id="teamUser9" tabindex="-1" role="dialog" aria-labelledby="teamUser9Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-9-lg.jpg" alt="Logan S. Perez">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser9Title">Logan S. Perez</h5>
                            <small class="text-muted mb-0 ">CEO & CFO</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser6 -->
    <div class="modal team-modal fade" id="teamUser6" tabindex="-1" role="dialog" aria-labelledby="teamUser6Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-6-lg.jpg" alt="Susan J. Newsom">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser6Title">Susan J. Newsom</h5>
                            <small class="text-muted mb-0 ">Graphic Designer</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser2 -->
    <div class="modal team-modal fade" id="teamUser2" tabindex="-1" role="dialog" aria-labelledby="teamUser2Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-2-lg.jpg" alt="Mary J. Wardle">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser2Title">Mary J. Wardle</h5>
                            <small class="text-muted mb-0 ">CPO</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser10 -->
    <div class="modal team-modal fade" id="teamUser10" tabindex="-1" role="dialog" aria-labelledby="teamUser10Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-10-lg.jpg" alt="Nicholas M. Sharpe">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser10Title">Nicholas M. Sharpe</h5>
                            <small class="text-muted mb-0 ">UI / UX Designer</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser4 -->
    <div class="modal team-modal fade" id="teamUser4" tabindex="-1" role="dialog" aria-labelledby="teamUser4Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-4-lg.jpg" alt="Cecelia T. Carter">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser4Title">Cecelia T. Carter</h5>
                            <small class="text-muted mb-0 ">CTO</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser13 -->
    <div class="modal team-modal fade" id="teamUser13" tabindex="-1" role="dialog" aria-labelledby="teamUser13Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-13-lg.jpg" alt="Terry T. Robinette">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser13Title">Terry T. Robinette</h5>
                            <small class="text-muted mb-0 ">Developer</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Advisors Team Modal Pop-ups -->
    <!-- teamUser1 -->
    <div class="modal team-modal fade" id="teamUser1" tabindex="-1" role="dialog" aria-labelledby="teamUser1Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-1-lg.jpg" alt="Nadia Sidko">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser1Title">Nadia Sidko</h5>
                            <small class="text-muted mb-0 ">Blockchain Entrepreneur</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser8 -->
    <div class="modal team-modal fade" id="teamUser8" tabindex="-1" role="dialog" aria-labelledby="teamUser8Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-8-lg.jpg" alt="Pavel Volek">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser8Title">Pavel Volek</h5>
                            <small class="text-muted mb-0 ">Entrepreneur and Investor</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser3 -->
    <div class="modal team-modal fade" id="teamUser3" tabindex="-1" role="dialog" aria-labelledby="teamUser3Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-3-lg.jpg" alt="Alyona Blakytna">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser3Title">Alyona Blakytna</h5>
                            <small class="text-muted mb-0 ">Fin-Tech Entrepreneur</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser11 -->
    <div class="modal team-modal fade" id="teamUser11" tabindex="-1" role="dialog" aria-labelledby="teamUser11Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-11-lg.jpg" alt="Martin Solarik">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser11Title">Martin Solarik</h5>
                            <small class="text-muted mb-0 ">Fin-Tech Investor</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser7 -->
    <div class="modal team-modal fade" id="teamUser7" tabindex="-1" role="dialog" aria-labelledby="teamUser7Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-7-lg.jpg" alt="Kate Fisenko">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser7Title">Kate Fisenko</h5>
                            <small class="text-muted mb-0 ">Fin-Tech Investor</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- teamUser12 -->
    <div class="modal team-modal fade" id="teamUser12" tabindex="-1" role="dialog" aria-labelledby="teamUser12Title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row p-4">
                        <div class="col-12 col-md-5">
                            <img class="img-fluid rounded" src="<?php echo base_url('assets/front/home/');?>theme-assets/images/user-12-lg.jpg" alt="Michal Krajnansky">
                        </div>
                        <div class="col-12 col-md-7 mt-sm-3">
                            <h5 id="teamUser12Title">Michal Krajnansky</h5>
                            <small class="text-muted mb-0 ">Blockchain Entrepreneur</small>
                            <div class="social-profile">
                                <a href="#" title="Linkedin" class="font-medium grey-accent2 mr-2"><i class="ti-linkedin"></i></a>
                                <a href="#" title="Twitter" class="font-medium grey-accent2 mr-2"><i class="ti-twitter-alt"></i></a>
                                <a href="#" title="Github" class="font-medium grey-accent2"><i class="ti-github"></i></a>
                            </div>
                            <div class="my-4">
                                <p>Experienced algorithmic crypto trader and a machine learning evangelist.</p>
                                <p>I’m focusing on the logic behind the combination of analysis tools, neural networks and genetic algorithms for optimization. Always wanted to have a trading bot with more features but never had the time to build a solution beyond basic python technical analysis tracker.</p>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Blockchain</small> <small class="float-right">85%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 85%;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">Python</small> <small class="float-right">90%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 90%;" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <h6 class="mb-0"><small class="text-uppercase">C++</small> <small class="float-right">75%</small></h6>
                            <div class="progress box-shadow-1 mb-4">
                                <div class="progress-bar progress-orange" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </main>
    </div>
    </div>
<!-- //////////////////////////////////// FOOTER ////////////////////////////////////-->
<style>
   .card-body.ptagcls6 p {
    color: #3f3f3f !important;
   }
   .rgb li {
    padding-bottom: 19px;
   }
   .card-body.ptagcls6 {
    text-align: justify;
   }
</style>
<?php $this->load->view('front/homepart/footer');?>