<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">
         <section class="flexbox-container account-content" id="account-login">
            <div id="particles-js"></div>
            <div class="login-content container-fluid">
               <div class="col-12 d-flex align-items-center justify-content-center">
                  <!-- image -->
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0 text-center d-none d-md-block">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 height-500 aligner-item">
                        <img src="<?php echo base_url('assets/front/customer/');?>app-assets/images/pages/account-login-new.png" class="card-account-img img-responsive" alt="card-account-img">
                     </div>
                  </div>
                  <!-- login form -->
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 card-account-right height-500">
                        <div class="card-content">
                           <div class="card-body p-3 account-bg-gradient">
                              <p class="text-center account-logo"><a href="<?php echo base_url();?>"><img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/logo.png" alt="Rewards2pay" /></a></p>
                              <?php if(!empty($error)){?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $error;?>
                              </div>
                              <?php } ?>
                              <?php if(!empty($success)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $success;?>
                              </div>
                              <?php } ?>
                              <p class="text-center">
                                 <a href="<?php echo base_url();?>" class="card-link white-link"><i class="fa fa-arrow-circle-left"></i> Back</a><a href="<?php echo base_url('sign-in');?>" class="card-link white-link">Sign In</a>
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
</div>