<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
      </div>
      <div class="content-body">
         <section id="account-login" class="flexbox-container account-content">
            <div id="particles-js"></div>
            <div class="login-content container-fluid">
               <div class="col-12 d-flex align-items-center justify-content-center">
                  <!-- image -->
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0 text-center d-none d-md-block">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 height-600">
                        <img src="<?php echo base_url('assets/front/customer/');?>app-assets/images/pages/account-login.png" class="card-account-img img-responsive" alt="card-account-img">
                     </div>
                  </div>
                  <!-- login form -->
                  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-5 col-12 p-0">
                     <div class="card border-grey border-lighten-3 m-0 box-shadow-0 card-account-right height-600 reset-height">
                        <div class="card-content">
                           <div class="card-body p-3 account-bg-gradient">
                              <p class="text-center h5 text-capitalize account-head">Welcome To</p>
                              <p class="text-center account-logo"><a href="<?php echo base_url();?>"><img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/account-logo.png" alt="Rewards2pay" class="img-responsive imglogo1" /></a></p>
                              <p class="mb-3 text-center account-subtitle">Reset Password</p>
                              <form class="form-horizontal form-signin" action="<?php echo base_url('reset-password'); ?>" method="post" name="resetfrm" id="resetfrm">
                                 <fieldset class="form-group">
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Your Username *" />
                                 </fieldset>
                                 <fieldset class="form-group">
                                    <span class="tool-info" data-toggle="tooltip" title="Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter New Password *" />
                                    </span>
                                 </fieldset>
                                 <fieldset class="form-group"><span class="tool-info" data-toggle="tooltip" title="Your password and confirm password must match.">
                                    <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Enter Confirm Password *" /> </span>
                                 </fieldset>
                                 <button type="submit" id="btn-submit" class="btn-gradient-primary account-gradiant-btn btn-block my-1">Submit <small id="loadingImg" style="display:none"><img src="<?php echo base_url('assets/front/loader/spin.gif')?>"></small></button>
                                 <p class="text-center">
                                    <a href="<?php echo base_url();?>" class="card-link white-link"><i class="fa fa-arrow-circle-left"></i> Back</a>
                                    <a href="<?php echo base_url('sign-in');?>" class="card-link white-link">Sign In</a>
                                 </p>
                              </form>
                              <?php if(!empty($error)){?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $error;?>
                              </div>
                              <?php } ?>
                              <?php if(!empty($success)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $success;?>
                              </div>
                              <?php } ?>
                              <script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/jquery.validate.min.js');?>"></script>
                              <script>
                                 //form validation rules
                                 $("#resetfrm").validate({
                                 rules: {
                                  username: "required",
                                   password : {
                                 minlength : 8,
                                 required: true
                                 },
                                 confirmpassword : {
                                 minlength : 8,
                                 required: true,
                                 equalTo: "#password"
                                 }
                                  
                                 }
                                 ,
                                 messages: {
                                  username: " ",
                                   password : {
                                 minlength : "",
                                 required: " "
                                 },
                                 confirmpassword : {
                                 minlength : "",
                                 required: " ",
                                 equalTo : "",
                                 }
                                  
                                 }
                                 ,
                                 submitHandler: function(form) {
                                  form.submit();
                                 $("#loadingImg").show();
                                   $(this).find("#btn-submit").prop('disabled', true);
                                 }
                                 }
                                 					 );
                              </script>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </div>
   </div>
</div>
<style>
@media only screen and (max-width: 660px) and (min-width: 320px){
.card.border-grey.border-lighten-3.m-0.box-shadow-0.card-account-right.height-600.reset-height {
    height: 300px !important;
}
}
</style>
