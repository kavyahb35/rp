<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/catalog/javascript/bootstrap/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/catalog/javascript/font-awesome/css/font-awesome.min.css')?>">
<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-body">
         <section id="account-login" class="flexbox-container account-content">
            <div id="particles-js"></div>
            <div class="login-content container-fluid">
               <div class="col-12 d-flex align-items-center justify-content-center">
                  <!-- image -->
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-5 col-12 p-0 text-center d-none d-md-block">
                     <div class="border-grey border-lighten-3 m-0 box-shadow-0 height-auto aligner-item">
                        <img src="<?php echo base_url('assets/front/customer/');?>app-assets/images/pages/account-login.png" class="card-account-img img-responsive" alt="card-account-img">
                     </div>
                  </div>
                  <!-- login form -->
                  <div class="col-xl-4 col-lg-5 col-md-7 col-sm-5 col-12 p-0">
                     <div class="card border-grey border-lighten-3 m-0 box-shadow-0 card-account-right height-auto register-height">
                        <div class="card-content">
                           <div class="card-body p-3 account-bg-gradient">
                              <p class="text-center h5 text-capitalize account-head">Welcome To</p>
                              <p class="text-center account-logo"><a href="<?php echo base_url();?>"><img src="<?php echo base_url('assets/front/home/');?>theme-assets/images/account-logo.png" alt="Rewards2pay" class="img-responsive imglogo1" /></a></p>
                              <p class="mb-3 text-center account-subtitle"> Sign Up Details</p>
                              <form class="form-horizontal form-signin" action="<?php echo base_url('sign-up'); ?>" method="post" name="registerfrm" id="registerfrm">
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First Name *"  value="" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last Name *"  value="" />
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <span class="tool-info" data-toggle="tooltip" title="Minimum 7 char required. You can use letters (a-z) and numbers (0-9).">
                                       <input type="text" class="form-control" id="username" name="username" placeholder="User Name *"  value="" /></span>
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="email" name="email" placeholder="Email *"  value="" />
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <span class="tool-info" data-toggle="tooltip" title="Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.">
                                       <input type="password" class="form-control" id="password" name="password" placeholder="Password *"  value="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[@#$%])(?=.*[A-Z]).{8,}" title="Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character." />
                                       </span>
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <span class="tool-info" data-toggle="tooltip" title="Your password and confirm password must match.">
                                       <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password *"  />
                                       </span>
                                    </fieldset>
                                 </div>
                                 <fieldset class="form-group ">
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Address *"  value="" />
                                 </fieldset>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="city" name="city"  placeholder="City *"  value="" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <select name="province" id="province" class="form-control">
                                          <?php if($province==''){ ?> 
                                          <option value="">- Province - </option>
                                          <?php } ?>
                                          <option value="Alberta" >Alberta</option>
                                          <option value="British Columbia" >British Columbia</option>
                                          <option value="Manitoba" >Manitoba</option>
                                          <option value="New Brunswick" >New Brunswick</option>
                                          <option value="Newfoundland and Labrador" >Newfoundland and Labrador</option>
                                          <option value="Northwest Territories" >Northwest Territories</option>
                                          <option value="Nova Scotia" >Nova Scotia</option>
                                          <option value="Nunavut" >Nunavut</option>
                                          <option value="Ontario" >Ontario</option>
                                          <option value="Prince Edward Island" >Prince Edward Island</option>
                                          <option value="Québec" >Québec</option>
                                          <option value="Saskatchewan" >Saskatchewan</option>
                                          <option value="Yukon Territory" >Yukon Territory</option>
                                       </select>
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="zipcode" name="zipcode" placeholder="Postal Code *"  value="" maxlength="7" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="country" name="country"  placeholder="Country *"  value="CA" readonly />
                                    </fieldset>
                                 </div>
                                 <div class="row">
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <input type="text" class="form-control" id="phone" name="phone" maxlength="12" placeholder="Phone *" onkeypress="return ValidatePhoneNo()" value="" />
                                    </fieldset>
                                    <fieldset class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                       <div class="input-group " id="date" >
                                          <input type="text"  placeholder="DoB *" id="dob" name="dob" data-date-format="DD/MM/YYYY" class="form-control" readonly value="" />
                                          <span class="input-group-btn topcls">
                                          <button class="btn btn-default" type="button"><i class="fa fa-calendar"></i></button>
                                          </span>
                                       </div>
                                    </fieldset>
                                 </div>
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                  <div class="row">
                                    <fieldset class="form-group col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                     <label class="card-link white-link"><input type="checkbox" name="terms" id="terms" value="1"> I agree to have read and accept Rewards2Pay <a class="card-link white-link" href="<?php echo base_url()?>#faq" target="_blank">Terms and Conditions and Privacy Statement</a> </label>
                                    </fieldset>
                                    
                                 </div>
                                 
                                 
                                 
                                 
                                 
                                 
                                 <button type="submit" id="btn-submit" class="btn-gradient-primary account-gradiant-btn btn-block my-1" >Sign Up <span id="loadingImg" style="display:none"><img src="<?php echo base_url('assets/front/loader/spin.gif')?>"></span></button>
                                 <p class="text-center">
                                    <a href="<?php echo base_url();?>" class="card-link white-link"><i class="fa fa-arrow-circle-left"></i> Back</a>
                                    <a href="<?php echo base_url('sign-in');?>" class="card-link white-link">Sign In</a>
                                 </p>
                              </form>
                              <?php if(!empty($error)){?>
                              <div class="alert alert-danger  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $error;?>
                              </div>
                              <?php } ?>
                              <?php if(!empty($success)){?>
                              <div class="alert alert-success  alert-dismissible msg">
                                 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                 </a>
                                 <?php  echo $success;?>
                              </div>
                              <?php } ?>
                              <script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/jquery.validate.min.js');?>"></script>
                              <script>
                                 //form validation rules
                                 $("#registerfrm").validate({
                                 rules: {
                                  username: {
                                               minlength : 7,
                                               required: true
                                       },
                                  password : {
                                               minlength : 8,
                                               required: true
                                       },
phone: {
                                               minlength : 10,
                                               required: true
                                       },
                                  cpassword : {
                                               minlength : 8,
                                               required: true,
                                               equalTo: "#password"
                                       },
                                       country:"required",
                                       province:"required",
                                  firstname: "required",
                                  lastname: "required",
                                  address: "required",
                                  email: "required",
                                  zipcode: "required",
                                  dob: "required",
                                  city: "required",
                                 terms: {
                required: true
            }
                                 }
                                 ,
                                 messages: {
                                   username: {
                                               minlength : "",
                                                required: " "
                                       },
                                   password : {
                                               minlength : "",
                                                required: " "
                                       },
                                   cpassword : {
                                           minlength : "",
                                           required: " ",
                                           equalTo : ""
                                   },
                                   country:"",
                                   province:"",
                                  firstname: " ",
                                  lastname: "",
                                  address: "",
                                   phone: {
                                               minlength : "",
                                                required: " "
                                       },
                                  email: "",
                                  zipcode: "",							  
                                  dob: "",	
                                  city: "",
                                  terms:"required"
                                 }
                                 ,
                                 submitHandler: function(form) {
                                 $("#num").hide();
                                  form.submit();
                                 $("#loadingImg").show();
                                   $(this).find("#btn-submit").prop('disabled', true);
                                 }
                                 }
                                 );
                              </script>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <script>
           // var today='18/07/2018';
               $('#date').datetimepicker({
                 format: 'dd/mm/yyyy',
               endDate: new Date(), 
               maxDate: new Date() 
                });	 
         </script>
         <script>
            function ValidatePhoneNo() {
              if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
                return event.returnValue;
              return event.returnValue = '';
            }
         </script> 
      </div>
   </div>
</div>
</div>
<style>


@media only screen and (min-width:320px) and (max-width:760px){
	.card.border-grey.border-lighten-3.m-0.box-shadow-0.card-account-right.height-auto.register-height {
          height: 200px ;
	}
}
</style>
