<?php header("Cache-Control: max-age=300, must-revalidate");?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta name="author" content="PIXINVENT">
      <title><?php echo 'Rewards2Pay - 404 Page Not Found!';?></title>
      <link rel="apple-touch-icon" href="<?php echo base_url('assets/front/customer/');?>app-assets/images/ico/apple-icon-120.png">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/front/');?>home/theme-assets/images/ico/favicon.png">
      <link href="https://fonts.googleapis.com/css?family=Muli:300,300i,400,400i,600,600i,700,700i|Comfortaa:300,400,500,700" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/css/vendors.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/css/forms/icheck/custom.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/css/app.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>assets/css/style.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/assets/js/datetimepicker/responsive.css');?>">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/moment.js');?>"></script>
      <link href="<?php echo base_url('assets/front/home/assets/js/datetimepicker/bootstrap.min.css');?>" rel="stylesheet" />
   </head>
   <body class="vertical-layout vertical-compact-menu 1-column  bg-full-screen-image menu-expanded blank-page blank-page" data-open="click" data-menu="vertical-compact-menu" data-col="1-column">
      <div class="error404" style="margin:0 auto;text-align: center">
         404 PAGE NOT FOUND!
      </div>
      <script src="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>      
      <script src="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/js/forms/icheck/icheck.min.js" type="text/javascript"></script>
      <script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/core/app-menu.js" type="text/javascript"></script>
      <script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/core/app.js" type="text/javascript"></script>
   </body>
</html>