<!DOCTYPE html>
<html lang="en" data-textdirection="ltr">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta http-equiv="X-UA-Compatible" content="IE=11">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta name="description" content="Rewards2pay.com">
      <meta name="keywords" content="Rewards2pay.com">
      <meta name="author" content="Rewards2pay.com">
      <title>Rewards2pay.com</title>
      <link rel="apple-touch-icon" href="<?php echo base_url('assets/front/home/');?>theme-assets/images/ico/apple-icon-120.png">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/front/home/');?>theme-assets/images/ico/favicon.png">
      <!--Google Fonts-->
      <link href="https://fonts.googleapis.com/css?family=Comfortaa:300,400,500,700" rel="stylesheet">
      <!--Font icons-->
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <!-- BEGIN VENDOR CSS-->
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/fonts/themify/style.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/fonts/flag-icon-css/css/flag-icon.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/vendors/animate/animate.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/vendors/flipclock/flipclock.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/vendors/swiper/css/swiper.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>assets/js/datetimepicker/responsive.css">     
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/css/template-3d-graphics.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>assets/css/style.css">
   </head>
   <body class=" 1-column   page-animated template-3g-graphics" data-menu-open="hover" data-menu="">
      <div id="loader-wrapper">
         <svg viewbox=" 0 0 512 512" id="loader">
            <linearGradient id="loaderLinearColors" x1="0" y1="0" x2="1" y2="1">
               <stop offset="5%" stop-color="#28bcfd"></stop>
               <stop offset="100%" stop-color="#1d78ff"></stop>
            </linearGradient>
            <g>
               <circle cx="256" cy="256" r="150" fill="none" stroke="url(#loaderLinearColors)" />
            </g>
            <g>
               <circle cx="256" cy="256" r="125" fill="none" stroke="url(#loaderLinearColors)" />
            </g>
            <g>
               <circle cx="256" cy="256" r="100" fill="none" stroke="url(#loaderLinearColors)" />
            </g>
            <g>
               <circle cx="256" cy="256" r="75" fill="none" stroke="url(#loaderLinearColors)" />
            </g>
            <circle cx="256" cy="256" r="60" fill="url(#loaderImage)" stroke="none" stroke-width="0" />
            <defs>
               <pattern id="loaderImage" height="100%" width="100%" patternContentUnits="objectBoundingBox">
                  <image href="<?php echo base_url('assets/front/home/');?>theme-assets/images/loader-logo.png" preserveAspectRatio="none" width="1" height="1"></image>
               </pattern>
            </defs>
         </svg>
         <div class="loader-section section-left"></div>
         <div class="loader-section section-right"></div>
      </div>
      <!--/ Preloader -->
      <nav class="vertical-social">
         <ul>
            <li><a href="#"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-medium" aria-hidden="true"></i></a></li>
            <li><a href="#"> <i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-github" aria-hidden="true"></i></a></li>
         </ul>
      </nav>
      <header class="page-header">
         <?php $this->load->view('front/homepart/nav');?>
      </header>