<?php header("Cache-Control: max-age=300, must-revalidate");?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head><title><?php echo $title;?></title>
   <meta name="description" content="<?php echo $metadescription;?>">
    <meta name="keywords" content="<?php echo $metakeyword;?>">
    <meta name="author" content="PIXINVENT">    
     <?php $this->load->view('customer/include/header');?>     
     <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/assets/js/datetimepicker/responsive.css');?>">
     
  </head>
  <body class="vertical-layout vertical-compact-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-compact-menu" data-col="2-columns">
    <?php $this->load->view('customer/include/nav');?>
    <?php $this->load->view($main);?>
    <?php $this->load->view('customer/include/footer');?>
    <?php $this->load->view('customer/include/common/js');?>  
  </body>
</html>
