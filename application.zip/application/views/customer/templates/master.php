<?php header("Cache-Control: max-age=300, must-revalidate");?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="X-UA-Compatible" content="IE=11">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="<?php echo $metadescription;?>">
    <meta name="keywords" content="<?php echo $metakeyword;?>">
    <meta name="author" content="PIXINVENT">
    <title><?php echo $title;?></title>
    <link rel="apple-touch-icon" href="<?php echo base_url('assets/front/customer/');?>app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/front/customer/');?>app-assets/images/ico/favicon.png">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,300i,400,400i,600,600i,700,700i|Comfortaa:300,400,500,700" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/css/vendors.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/css/forms/icheck/icheck.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/css/forms/icheck/custom.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN MODERN CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/css/app.css">
    <!-- END MODERN CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/css/core/menu/menu-types/vertical-compact-menu.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/css/cryptocoins/cryptocoins.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>app-assets/css/pages/account-login.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer/');?>assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/');?>theme-assets/css/template-3d-graphics.css">
    <!-- END Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/home/assets/js/datetimepicker/responsive.css');?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/jquery-2.1.1.min.js');?>"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
	<script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/moment.js');?>"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/front/home/assets/js/datetimepicker/bootstrap-datetimepicker.min.css');?>">
	<script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/bootstrap-datetimepicker.min.js');?>"></script>
	<link href="<?php echo base_url('assets/front/home/assets/js/datetimepicker/bootstrap.min.css');?>" rel="stylesheet" />
	<script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/bootstrap.min.js');?>"></script>
	<script src="<?php echo base_url('assets/front/home/');?>assets/js/common.js"></script>
  </head>
  <!--<body class="vertical-layout vertical-compact-menu 1-column  bg-full-screen-image menu-expanded blank-page blank-page" data-open="click" data-menu="vertical-compact-menu" data-col="1-column">-->
  <body class="vertical-layout vertical-compact-menu 1-column menu-expanded blank-page blank-page bg-gradient" data-open="click" data-menu="vertical-compact-menu" data-col="1-column">
   <?php $this->load->view($main);?>
    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/js/forms/icheck/icheck.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN MODERN JS-->
    <script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/core/app-menu.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/core/app.js" type="text/javascript"></script>
    <!-- END MODERN JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/scripts/forms/form-login-register.js" type="text/javascript"></script>
	<script src="<?php echo base_url('assets/front/home/');?>theme-assets/vendors/particles.min.js"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN THEME JS-->
	<script src="<?php echo base_url('assets/front/home/');?>theme-assets/js/scripts/particles-type1.js"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>

