<div class="app-content content dashboard-layout">
<div class="content-wrapper">
   <div class="content-header row">
      <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
         <h3 class="content-header-title mb-0 d-inline-block">Dashboard</h3>
      </div>
      <div class="content-header-right col-md-4 col-12 d-md-inline-block btn-add-prog">
         <div class="btn-group float-md-right"><a class="btn-gradient-secondary btn-gradient-redyellow btn-sm white pull-right" href="<?php echo base_url('manage-cards');?>">Add Loyalty Program</a></div>
      </div>
   </div>
   <div class="content-body">
      <!-- wallet balance  -->
      <div class="row">
         <div class="col-md-12 col-12">
            <h6 class="my-2">Your Balance</h6>
            <div class="card pull-up">
               <div class="card-content">
                  <div class="card-body">
                     <div class="row dash-points">
                        <?php $walletbalance = $this->session->userdata['walletCustomerDetails']['walletbalance'];
                           $softWalletBalance = $this->session->userdata['walletCustomerDetails']['softWalletBalance'];
                           $estimatedWalletValue = $this->session->userdata['walletCustomerDetails']['estimatedWalletValue'];?>
                        <div class="col-sm-12 col-md-4  col-lg-4  col-xs-12 blg1 right-boder">
                           <div class="row ">
                              <div class="col-sm-12 col-md-12 col-lg-6  col-xs-12 blg1">
                                 <p class="est-cash-title"><strong>Estimated Cash Balance <span class="tool-info" data-toggle="tooltip" title="Please know this balance is based on market valuation of the points for your Loyalty Program. This is not the same as the conversion balance. Please note the redemption value offered by Rewards2Pay platform for your Rewards2Pay program. "> ?</span></strong></p>
                                 <h1 class="est-cash"><?php if($estimatedWalletValue!=''){ echo $estimatedWalletValue; }else { echo '0';}?> <span>CAD</span></h1>
                              </div>
                              <div class="col-sm-12 col-md-12  col-lg-6  col-xs-12  blg1">
                                 <div class="btn-redeem blg1">
                                    <a href="<?php echo base_url('wallet'); ?>"><button class=" btn-gradient-reedem btn-sm white line-height-3">Redeem</button></a>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-12 col-md-4  col-lg-4  col-xs-12  blg12 right-boder">
                           <p class="est-cash-title"><strong>Authorizing Cash Balance<span class="tool-info" data-toggle="tooltip" title="We authorizing points redemption from your Loyalty program accounts. Once authorized the amount will be deposited in your Rewards2Pay Wallet Balance for Payouts. This can take upto 10 working days. "> ?</span></strong></p>
                           <h1 class="est-cash"><?php if($softWalletBalance!=''){ echo $softWalletBalance; }else { echo '0';}?> <span>CAD</span></h1>
                        </div>
                        <div class="col-sm-12 col-md-4  col-lg-4  col-xs-12  blg1 ">
                           <div class="row ">
                              <div class="col-sm-12 col-md-12  col-lg-6  col-xs-12  blg1 ">
                                 <p class="est-cash-title"><strong>Rewards2Pay Wallet Balance</strong></p>
                                 <h1 class="est-cash"><?php if($walletbalance!=''){ echo $walletbalance; }else { echo '0';}?> <span>CAD</span></h1>
                              </div>
                              <div class="col-sm-12 col-md-12  col-lg-5 col-xs-12  blg1">
                                 <form action="<?php echo base_url('paypal/buy')?>" method="post">
                                    <input type="hidden" name="balanceval" value="<?php echo $walletbalance;?>" />
                                    <button type="submit" class="btn-gradient-secondary ">Payout </button>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!--/ wallet -->
         <!--/ Customer Card -->
         <div class="dashboard-card col-12">
            <div class="row dash-prog-title">
               <div class="col-md-12 col-12">
                  <h6 class="my-2">Your Loyalty Program</h6>
               </div>
            </div>
            <div class="row rowsafari">
               <?php if(!empty($success)) {  ?>
               <?php foreach($success as $response) { ?>
               <?php $imgs = $response['progId']; ?>
               <?php $img = $imgs.'.png'; ?>
               <?php if (file_exists(FCPATH.'assets/front/customer/app-assets/images/cards/250/'.$img)){ ?>
               <?php $image = base_url('assets/front/customer/app-assets/images/cards/250/'.$img); ?>
               <?php } else { ?>
               <?php $image = base_url('assets/front/customer/app-assets/images/cards/250/dummy.png'); ?>
               <?php } ?>
               <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="pull-up">
                     <div class="card">
                        <div class="card-img text-center">
                           <img class="img-responsive" src="<?php echo $image;?>" alt="Aeroplane">
                        </div>
                        <div class="card-body text-center">
                           <h5 class="card-title"><?php echo $response['programName'];?></h5>
                        </div>
                        <div class="card-img text-center card-barcode">
                           <?php if($response['canBarcodeStandard']!=''){ ?>
                           <?php if($response['canBarcodeStandard']=='code_128'){ if( $response['cardNumber']!=''){ ?>
                           <img class="img-responsive" src="barcode.php?f=png&s=code-128&d=<?php echo $response['cardNumber']; ?>&ABCD">
                           <?php } } else { ?>
                           <img class="img-responsive" src="barcode.php?f=png&s=ean-13&d=<?php echo $response['cardNumber']; ?>&*">
                           <?php } ?>
                           <?php } ?>
                        </div>
                     </div>
                  </div>
               </div>
               <?php } ?>
               <?php }else {?>
               <div class="card pull-up" style=" width: 97%;  margin-left: 16px;">
                  <div class="card-content">
                     <div class="card-body">
                        <div class="col-12">
                           <div class="row">
                              <div class="col-md-12 col-12">
                                 <p class="est-cash-title"><strong>Program not found!</strong></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php } ?>
            </div>
         </div>
      </div>
   </div>
</div>

