

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/customer')?>/app-assets/css/pages/transactions.css">
<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
         <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Transactions</h3>
         </div>
         <div class="content-header-right col-md-4 col-12 d-none d-md-inline-block">
         </div>
      </div>
      <div class="content-body">
         <div id="transactions">
            <div class="transactions-table-th d-none d-md-block">
               <div class="col-12">
                  <div class="row">
                     <div class="col-md-2 col-12 py-1">
                        <p class="mb-0">Transaction Date</p>
                     </div>
                     <div class="col-md-3 col-12 py-1">
                        <p class="mb-0">Description</p>
                     </div>
                     <div class="col-md-2 col-12 py-1">
                        <p class="mb-0">Starting Balance <br>/ Ending Balance</p>
                     </div>
                     <div class="col-md-2 col-12 py-1">
                        <p class="mb-0">Order Details</p>
                     </div>
                     <div class="col-md-1 col-12 py-1">
                        <p class="mb-0">Status</p>
                     </div>
                     <div class="col-md-2 col-12 py-1">
                        <p class="mb-0">Wallet Details</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="transactions-table-tbody">
               <?php if(!empty($success)){ 
                  foreach($success as $response){
                        $imgs = $response->progId;
                        $img = $imgs.'.png';
                        if (file_exists(FCPATH.'assets/front/customer/app-assets/images/cards/75/'.$img)){
                            $image=base_url('assets/front/customer/app-assets/images/cards/75/'.$img);
                        }else{
                            $image=base_url('assets/front/customer/app-assets/images/cards/75/dummy.png');
                        }
                      ?>
               <section class="card pull-up transaction-list">
                  <div class="card-content">
                     <div class="card-body">
                        <div class="col-12">
                           <div class="row">
                              <div class="col-md-12 col-12 py-1 col-sm-12 col-lg-2 ">
                                 <p class="mb-0"> <span class="d-inline-block d-md-none text-bold-700">Date : </span>  <?php  $timestems = $response->lastUpdated;
                                    $dt = date(' M-d, Y H:i A', '1530243846'); echo $dt;?> </p>
                              </div>
                              <div class="col-sm-12 col-lg-3 col-md-12 col-12 py-1 ">
                                 <div class="media">
                                   
                                  <?php if($imgs!=''){ ?>  <img src="<?php echo $image;?>" /> <?php } ?>
                                    <div class="media-body">
                                       <h5 class="mt-0 text-capitalize wallet-card-name"> <?php $progid = $response->progId;
                                          $exp = explode('_',$progid); echo $exp[1];
                                          ?></h5>
                                       <p class="text-muted mb-0 font-small-3 wallet-address">  <span class="d-inline-block d-md-none text-bold-700">Order ID : </span> <?php echo $response->orderId;?></p>
                                         <p class="text-muted mb-0 font-small-3 wallet-address">  <span class="d-inline-block d-md-none text-bold-700">Payment ID : </span> <?php echo $response->paymentId;?></p>
                                       
                                    </div>
                               
                                 </div>
                              </div>
                              <div class="col-md-12 col-lg-2 col-12 py-1 col-sm-12 ">
                                 <?php if($response->orderId!=''){ ?>
                                 <p class="mb-0"> 
                                 <h6 class="card-point"><span class="d-inline-block d-md-none text-bold-700">Starting Points Balance : </span>  <?php echo  $response->curProgPointBalance;  ?> <span> Points</span></h6>
                                 </p>
                                 <p class="mb-0">
                                 <h6 class="card-point"><span class="d-inline-block d-md-none text-bold-700">Ending Points Balance : </span>  <?php echo  $response->softPointBal;  ?> <span> Points</span></h6>
                                 </p>
                                 <?php } ?>  
                              </div>
                              <div class="col-md-12 col-lg-2 col-12 py-1 col-sm-12 ">
                                 <?php if($response->orderId!=''){ ?>
                                 <p class="mb-0"> 
                                 <h6 class="card-point"><span class="d-inline-block d-md-none text-bold-700">Order Point : </span> <?php echo  $response->orderPointValue;  ?> <span> Points</span></h6>
                                 </p>
                                 <p class="mb-0"> 
                                 <h6 class="card-point"><span class="d-inline-block d-md-none text-bold-700">Order Cash : </span> <?php echo  $response->orderCashValue;  ?> <span> CAD</span></h6>
                                 </p>
                                 <?php } ?> 
                              </div>
                              <div class="col-md-12 col-lg-1 col-12 py-1 col-sm-12">
                                 <a class="mb-0 btn-sm btn transactioncls <?php
                                    if($response->status=='ACTIVE'){ echo 'btn-outline-success';}
                                    if($response->status=='COMPLETED'){ echo 'btn-outline-success';}
                                    if($response->status=='PENDING'){ echo 'btn-outline-warning';}
                                    
                                    ?> round"><?php echo $response->status;?></a>
                              </div>
                              <div class="col-md-12 col-lg-2 col-12 py-1 col-sm-12 walletpnt " >
                                 <p class="mb-0"> 
                                 <h6 class="card-point"><span class="d-inline-block d-md-none text-bold-700">Wallet Balance : </span> <?php echo  $response->walletBalance;  ?> <span> CAD</span></h6>
                                 </p>
                                 <p class="mb-0"> 
                                 <h6 class="card-point"><?php echo  $response->softWalletBalance;  ?> <span> CAD</span><br> <span style="    text-transform: capitalize;">( Pending Authorization ) </span></h6>
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <?php } } else {
                  echo '<div class="transactionmsg">Transaction history not found.</div>';
                  }?>
            </div>
         </div>
      </div>
   </div>
</div>
<style>
    @media only screen and (min-width:990px) and (max-width:1200px){
        a.mb-0.btn-sm.btn.transactioncls.btn-outline-success.round {
            font-size: 8px;
            padding: 5px 6px;
        }
        a.mb-0.btn-sm.btn.transactioncls.btn-outline-warning.round {
            font-size: 8px;
            padding: 5px 6px;
        }
        .col-md-12.col-lg-2.col-12.py-1.col-sm-12.walletpnt {
            padding: 0px 25px;
        }
   }
   @media only screen and (min-width:1200px) and (max-width:1400px){
    a.mb-0.btn-sm.btn.transactioncls.btn-outline-success.round {
        font-size: 10px;
        padding: 5px 11px;
    }
    a.mb-0.btn-sm.btn.transactioncls.btn-outline-warning.round {
        font-size: 10px;
        padding: 5px 11px;
    }
    .col-md-12.col-lg-2.col-12.py-1.col-sm-12.walletpnt {
        padding: 0px 25px;
    }
   }
   @media only screen and (min-width:1400px) and (max-width:1600px){
    a.mb-0.btn-sm.btn.transactioncls.btn-outline-success.round {
        font-size: 11px;
        padding: 5px 13px;
    }
    a.mb-0.btn-sm.btn.transactioncls.btn-outline-warning.round {
        font-size: 11px;
        padding: 5px 13px;
    }
    .col-md-12.col-lg-2.col-12.py-1.col-sm-12.walletpnt {
        padding: 0px 25px;
    }
   }
   @media only screen and (min-width:690px) and (max-width:990px){
    a.mb-0.btn-sm.btn.transactioncls.btn-outline-success.round {
        padding: 0.5rem 0.75rem;
        font-size: 0.875rem;
    }
    a.mb-0.btn-sm.btn.transactioncls.btn-outline-warning.round {
        padding: 0.5rem 0.75rem;
        font-size: 0.875rem;
    }
    .col-md-12.col-lg-2.col-12.py-1.col-sm-12.walletpnt {
        padding: 0px 25px;
    }
   }
</style>
