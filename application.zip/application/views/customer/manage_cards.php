<div class="app-content content dashboard-layout">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
               <h3 class="content-header-title mb-0 d-inline-block">Manage Your Cards</h3>
            </div>
        </div>
        <div class="content-body">
           <!--/ Customer Card -->
            <div class="customer-card">
                <div class="row">
                   <?php if(!empty($loginProgram)){
                      foreach($loginProgram as $response){ 
                          $imgs = $response->progId;
                          $img = $imgs.'.png';
                           if (file_exists(FCPATH.'assets/front/customer/app-assets/images/cards/250/'.$img)){
                              $image=base_url('assets/front/customer/app-assets/images/cards/250/'.$img);
                              }else{
                              $image=base_url('assets/front/customer/app-assets/images/cards/250/dummy.png');
                              }
                          ?>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
                       <div class="pull-up">
                          <div class="card">
                             <div class="card-img">
                                <img class="img-responsive" src="<?php echo $image;?>" alt="<?php echo $response->programName;?>" />
                             </div>
                             <div class="card-body text-center">
                                <span class="mng-btn"><button class="btn-gradient-manage btn-sm white line-height-3" data-toggle="modal" data-target="#view-card-<?php echo $response->progId;?>">View Card Details</button></span>
                             </div>
                          </div>
                       </div>
                    </div>
                    <div class="modal fade registered-card-popup" id="view-card-<?php echo $response->progId;?>" tabindex="-1" role="dialog" aria-labelledby="view-card-<?php echo $response->progId;?>" aria-hidden="true">
                       <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                          <div class="modal-content">
                             <div class="modal-header">
                                <h5 class="modal-title" id="registeredModalLabel"><?php echo $response->programName;?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                             </div>
                             <div class="modal-body">
                                <div class="card-content">
                                   <div class="card-body">
                                      <div class="col-12">
                                         <div class="row">
                                            <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                            <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 text-center">
                                               <img class="img-responsive" src="<?php echo $image;?>" alt="<?php echo $response->programName;?>" />
                                            </div>
                                            <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                                <div class="text-center">
                                   <h6 class="card-name"><?php echo $response->programName;?></h6>
                                   <p class="card-point">Point Balance : <span><?php echo $response->pointBalance;?></span></p>
                                   <p class="card-updated">Last Updated : <span><?php $timestem =  $response->lastUpdated;
                                      $dt =  date(' M-d, Y', $timestem); if($dt==''){ echo 'Jun-18,2018'; }else { echo $dt;} ?></span></p>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                   <?php }
                      }
                      ?>
                   <?php if(!empty($withoutLoginProgram)){
                      foreach($withoutLoginProgram as $response){
                          if($response['progId']!='' && ($response['canManage']=='Y' || $response['canMonitor']=='Y')){

                          $imgs = $response['progId'];
                          $img = $imgs.'.png';
                           if (file_exists(FCPATH.'assets/front/customer/app-assets/images/cards/250/'.$img)){
                              $image=base_url('assets/front/customer/app-assets/images/cards/250/'.$img);
                              }else{
                              $image=base_url('assets/front/customer/app-assets/images/cards/250/dummy.png');
                              }
                          ?>
                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4">
                       <div class="pull-up">
                          <div class="card">
                             <div class="card-img">
                                <img class="img-responsive" src="<?php echo $image;?>" alt="<?php echo $response['programName'];?>" />
                             </div>
                             <div class="card-body text-center">
                                <?php if($response['canManage']=='Y'){ ?>
                                <span class="mng-btn"><button class="btn-gradient-manage btn-sm white line-height-3" data-toggle="modal" data-target="#manual-card-<?php echo $response['progId'];?>">Enter Card Manually</button></span>
                                <?php } if($response['canMonitor']=='Y'){?> <span class="mng-btn"><button class="btn-gradient-manage btn-sm white line-height-3" data-toggle="modal" data-target="#monitor-card-<?php echo $response['progId'];?>">Monitor Your Card</button></span>
                                <?php }?>
                             </div>
                          </div>
                       </div>
                    </div>
                    <div class="modal fade monitor-card-popup" id="monitor-card-<?php echo $response['progId'];?>" tabindex="-1" role="dialog" aria-labelledby="monitor-card" aria-hidden="true">
                       <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                          <div class="modal-content">
                             <div class="modal-header">
                                <h5 class="modal-title" id="monitorModalLabel">Monitor Your Card</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                             </div>
                             <div class="modal-body">
                                <div class="card-content">
                                   <div class="card-body">
                                      <div class="col-12">
                                         <div class="row">
                                            <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                            <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 text-center">
                                               <img class="img-responsive" src="<?php echo $image;?>" alt="<?php echo $response['programName'];?>" />
                                            </div>
                                            <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                                <form class="form form-horizontal mt-2 mx-2" novalidate id="form-<?php echo $response['progId'];?>" method="post">
                                   <div class="form-body">
                                      <div class="row">
                                         <input type="hidden" name="programid"  value="<?php echo $response['progId'];?>">
                                         <input type="hidden" name="programidname"  value="<?php echo $response['programName'];?>">
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6">
                                            <div class="input-group text-center">
                                               <input type="text" class="form-control"  placeholder="Username" name="username"  >
                                               <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon4"><i class="fa fa-user"></i></span>
                                               </div>
                                            </div>
                                            <div class="p-1"></div>
                                            <div class="input-group text-center">
                                               <input type="password" class="form-control"  placeholder="Password" name="password"  is="iron-input">
                                               <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon4"><i class="fa fa-lock"></i></span>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                      </div>
                                      <div class="row row-next">
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 text-center">
                                            <div class="btn-add-card">
                                               <a class="btn-gradient-secondary btn-gradient-redyellow btn-sm white" onclick="loginNewProgram('<?php echo $response['progId'];?>')">Add My Card <small id="loadingImg" style="display:none"><img src="<?php echo base_url('assets/front/loader/spin.gif')?>"></small></a>
                                            </div>
                                         </div>
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                      </div>
                                   </div>
                                </form>
                             </div>
                          </div>
                       </div>
                    </div>
                    <div class="modal fade manual-card-popup" id="manual-card-<?php echo $response['progId'];?>" tabindex="-1" role="dialog" aria-labelledby="manual-card-<?php echo $response['progId'];?>" aria-hidden="true">
                       <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                          <div class="modal-content">
                             <div class="modal-header">
                                <h5 class="modal-title" id="manualModalLabel">Enter Card Manually</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                             </div>
                             <div class="modal-body">
                                <div class="card-content">
                                   <div class="card-body">
                                      <div class="col-12">
                                         <div class="row">
                                            <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                            <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 text-center">
                                               <img class="img-responsive" src="<?php echo $image;?>" alt="Aeroplane" />
                                            </div>
                                            <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                                <form class="form form-horizontal mt-2 mx-2" novalidate id="form-card-<?php echo $response['progId'];?>" method="post">
                                   <div class="form-body">
                                      <div class="row">
                                         <input type="hidden" name="programid"  value="<?php echo $response['progId'];?>">
                                         <input type="hidden" name="programidname"  value="<?php echo $response['programName'];?>">
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6">
                                            <div class="input-group text-center">
                                               <input type="text" class="form-control" name="cardnumber" aria-describedby="basic-addon4">
                                               <div class="input-group-append">
                                                  <span class="input-group-text" id="basic-addon4"><i class="fa fa-credit-card"></i></span>
                                               </div>
                                            </div>
                                         </div>
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                      </div>
                                      <div class="row row-next">
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                         <div class="col-xs-12 col-sm-8 col-md-6 col-lg-6 text-center">
                                            <div class="btn-add-card">
                                               <a class="btn-gradient-secondary btn-gradient-redyellow btn-sm white" onclick="loginNewProgramByCard('<?php echo $response['progId'];?>')">Add My Card <small id="loadingImg1" style="display:none"><img src="<?php echo base_url('assets/front/loader/spin.gif')?>"></small></a>
                                            </div>
                                         </div>
                                         <div class="col-xs-hidden col-sm-2 col-md-3 col-lg-3"></div>
                                      </div>
                                   </div>
                                </form>
                             </div>
                          </div>
                       </div>
                    </div>
                   <?php } }
                      }
                      ?>
                </div>
            </div>
           <!--/ Customer Card -->
        </div>
   </div>
</div>
<script>
   var jq = $.noConflict();
   function loginNewProgram(id)
   {
       $("#loadingImg").show();
       var url ="<?php echo base_url('managecards/addProgram');?>";
       $.ajax({
       type: 'post',
       dataType : 'json',
       url: url,            
       data: $("#form-"+id).serialize(),
       success: function (data) {
          if(data.succ=='1'){
               $("#loadingImg").hide();
                       $('#monitor-card-'+id).modal('hide');
                       jq.dialog({
                               title: 'Success!',
                               content: data.success,
                               onClose: function () {
                                       location.reload();
                               },
                       });
   
               } if(data.err=='2'){
                    $("#loadingImg").hide();
                            jq.dialog({
                                   title: 'Warning!',
                                   content: data.error
                            });
                     }
           }
     });
   }
   function loginNewProgramByCard(id)
   {
        $("#loadingImg1").show();
       var url ="<?php echo base_url('managecards/addCardProgram');?>";
           $.ajax({
           type: 'post',
           dataType : 'json',
           url: url,            
           data: $("#form-card-"+id).serialize(),
           success: function (data) {
              if(data.succ=='1'){
                   $("#loadingImg1").hide();
                           $('#manual-card-'+id).modal('hide');
                           jq.dialog({
                                   title: 'Success!',
                                   content: data.success,
                                   onClose: function () {
                                           location.reload();
                                   },
                           });			  
                   }
                    if(data.err=='2'){
                         $("#loadingImg1").hide();
                            jq.dialog({
                                   title: 'Warning!',
                                   content: data.error
                            });
                     }
           }
     });
   }
</script>