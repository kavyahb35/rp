<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
         <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block"> Change Password</h3>
            <div class="row breadcrumbs-top d-inline-block">
               <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Dashboard</a>
                     </li>
                  </ol>
               </div>
            </div>
         </div>
      </div>
      <div class="content-body">
         <div class="row">
            <div class="col-12 col-md-12">
               <!-- User Profile -->
               <section class="card">
                  <div class="card-content">
                     <div class="card-body">
                        <div class="col-12">
                           <div class="row">
                              <div class="col-md-12 col-12">
                                 <div class="row">
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">Transactions</p>
                                       <p class="mb-0">12/14</p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">Last login</p>
                                       <p class="mb-0"><?php echo $this->session->userdata['customerprofiles']['lastUpdate'];?></p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">IP</p>
                                       <p class="mb-0"><?php echo $this->input->server('REMOTE_ADDR');?></p>
                                    </div>
                                 </div>
                                 <hr/>
                                 <?php if(!empty($error)){?>
                                 <div class="alert alert-danger  alert-dismissible msg">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $error;?>
                                 </div>
                                 <?php } ?>
                                 <?php if(!empty($success)){?>
                                 <div class="alert alert-success  alert-dismissible msg">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $success;?>
                                 </div>
                                 <?php } ?>
                                 <form class="form-horizontal form-user-profile row mt-2" action="<?php echo base_url('user/updatepassword'); ?>" method="post" name="registerfrm" id="registerfrm">
                                    <div class="col-12">
                                       <fieldset class="form-label-group">
                                          <input type="password"  class="form-control" id="oldpassword" name="oldpassword" placeholder="Enter Old Password" />
                                       </fieldset>
                                    </div>
                                    <div class="col-12">
                                       <fieldset class="form-label-group">   
                                          <span class="tool-info" data-toggle="tooltip" title="Minimum 8 char required. Password must contain at least 1 lowercase, 1 uppercase, 1 digit & 1 special character.">
                                          <input type="password"  class="form-control" id="password" name="password" placeholder="Enter New Password" />
                                          </span>
                                       </fieldset>
                                    </div>
                                    <div class="col-12">
                                       <fieldset class="form-label-group">
                                          <span class="tool-info" data-toggle="tooltip" title="Your password and confirm password must match.">
                                          <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Enter Confirm Password">
                                          </span>
                                       </fieldset>
                                    </div>
                                    <div class="col-12 text-right">
                                       <button id="btn-submit" type="submit" class="btn-gradient-primary my-1">Save <span id="loadingImg" style="display:none"><img src="<?php echo base_url('assets/front/loader/spin.gif')?>"></span>
                                       </button>
                                    </div>
                                 </form>
                                 <script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/jquery.validate.min.js');?>"></script>
                                 <script>
                                    //form validation rules
                                    $("#registerfrm").validate({
                                        rules: {
                                           oldpassword: "required",
                                           password : {
                                                required: true
                                           },
                                           confirmpassword : {
                                                required: true,
                                           }                                    
                                        },
                                        messages: {
                                            oldpassword: " ",
                                           password : {
                                                required: ""
                                            },
                                            confirmpassword : {
                                                required: "",
                                            }                                    
                                        },
                                        submitHandler: function(form) {
                                            form.submit();
                                            $("#loadingImg").show();
                                            $(this).find("#btn-submit").prop('disabled', true);
                                        }
                                    });
                                 </script>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </div>
   </div>
</div>