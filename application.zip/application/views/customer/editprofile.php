<div class="app-content content">
<div class="content-wrapper">
   <div class="content-header row">
      <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
         <h3 class="content-header-title mb-0 d-inline-block"> Profile</h3>
         <div class="row breadcrumbs-top d-inline-block">
            <div class="breadcrumb-wrapper col-12">
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Dashboard</a>
                  </li>
               </ol>
            </div>
         </div>
      </div>
      <div class="content-body">
         <div class="row">
            <div class="col-12 col-md-8">
               <!-- User Profile -->
               <section class="card">
                  <div class="card-content">
                     <div class="card-body">
                        <div class="col-12">
                           <div class="row">
                              <div class="col-md-12 col-12">
                                 <div class="row">
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">Transactions</p>
                                       <p class="mb-0">12/14</p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">Last login</p>
                                       <p class="mb-0"><?php echo $this->session->userdata['customerprofiles']['lastUpdate'];?></p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">IP</p>
                                       <p class="mb-0"><?php echo $this->input->server('REMOTE_ADDR');?></p>
                                    </div>
                                 </div>
                                 <hr/>
                                 <?php if(!empty($error)){?>
                                 <div class="alert alert-danger  alert-dismissible msg">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $error;?>
                                 </div>
                                 <?php } ?>
                                 <?php if(!empty($success)){?>
                                 <div class="alert alert-success  alert-dismissible msg">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $success;?>
                                 </div>
                                 <?php } ?>
                                 <form class="form-horizontal form-user-profile row mt-2" action="<?php echo base_url('update-profile'); ?>" method="post" name="registerfrm" id="registerfrm">
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" name="firstname" class="form-control" id="firstname" value="<?php echo $this->session->userdata['customerprofiles']['firstName'];?>" readonly>
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" name="lastname" class="form-control" id="lastname" value="<?php echo $this->session->userdata['customerprofiles']['lastName'];?>" readonly>
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="email" name="email" value="<?php echo $this->session->userdata['customerprofiles']['userEmail'];?>" placeholder="Enter Email Id" >
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone" value="<?php echo $this->session->userdata['customerprofiles']['phone'];?>"  placeholder="Enter Phone">
                                       </fieldset>
                                    </div>
                                    <div class="col-12">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="address" name="address" value="<?php echo $this->session->userdata['customerprofiles']['address'];?>"  placeholder="Enter Address">
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="zipcode" placeholder="Enter Postal Code" name="zipcode" placeholder="<?php echo $this->session->userdata['customerprofiles']['zipCode'];?>"   maxlength="7" >
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <div class="input-group " id="date">
                                             <input type="text"  placeholder="DoB" id="dob" name="dob" data-date-format="DD/MM/YYYY" class="form-control" readonly value="<?php echo $this->session->userdata['customerprofiles']['dob'];?>"  placeholder="Enter DoB">
                                             <span class="input-group-btn topcls">
                                             <button class="btn btn-default" type="button"><i class="fa fa-calendar"></i></button>
                                             </span>
                                          </div>
                                       </fieldset>
                                    </div>
                                    <div class="col-12 text-right">
                                       <button type="submit" class="btn-gradient-primary my-1">Save</button>
                                    </div>
                                 </form>
                                 <script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/jquery.validate.min.js');?>"></script>
                                 <script>
                                    //form validation rules
                                    $("#registerfrm").validate({
                                        rules: {
                                            firstname: "required",
                                            lastname: "required",
                                            address: "required",
                                            phone: "required",
                                            email: "required",
                                        },
                                        messages: {
                                            firstname: "",
                                            lastname: "",
                                            address: "",
                                            phone: "",
                                            email: "",
                                        },
                                        submitHandler: function(form) {
                                            $("#num").hide();
                                               form.submit();
                                            }
                                    });
                                 </script>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
            <div class="col-12 col-md-4">
               <div class="card">
                  <div class="card-header">
                     <h6 class="card-title text-center">ICO Tokens</h6>
                  </div>
                  <div class="card-content collapse show">
                     <div class="card-body">
                        <div class="text-center row clearfix mb-2">
                           <div class="col-12">
                              <i class="icon-layers font-large-3 bg-warning bg-glow white rounded-circle p-3 d-inline-block"></i>
                           </div>
                        </div>
                        <h3 class="text-center">3,458.88 CIC</h3>
                     </div>
                     <div class="table-responsive">
                        <table class="table table-de mb-0">
                           <tbody>
                              <tr>
                                 <td>CIC Token</td>
                                 <td><i class="icon-layers"></i> 3,258 CIC</td>
                              </tr>
                              <tr>
                                 <td>CIC Referral</td>
                                 <td><i class="icon-layers"></i> 200.88 CIC</td>
                              </tr>
                              <tr>
                                 <td>CIC Price</td>
                                 <td><i class="cc BTC-alt"></i> 0.0001 BTC</td>
                              </tr>
                              <tr>
                                 <td>Raised BTC</td>
                                 <td><i class="cc BTC-alt"></i> 2154 BTC</td>
                              </tr>
                              <tr>
                                 <td>Raised USD</td>
                                 <td><i class="la la-dollar"></i> 4.52 M</td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
               <div class="card">
                  <div class="card-header">
                     <h6 class="card-title text-center">Token sale progress</h6>
                  </div>
                  <div class="card-content collapse show">
                     <div class="card-body">
                        <div class="font-small-3 clearfix">
                           <span class="float-left">$0</span>
                           <span class="float-right">$5M</span>
                        </div>
                        <div class="progress progress-sm my-1 box-shadow-2">
                           <div class="progress-bar bg-warning" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="font-small-3 clearfix">
                           <span class="float-left">Distributed <br> <strong>6,235,125 CIC</strong></span>
                           <span class="float-right text-right">Contributed  <br> <strong>5478 ETH | 80 BTC</strong></span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
   var today='13/07/2018';
      $('#date').datetimepicker({
      startDate: '21/05/2011', 
      format: 'dd/mm/yyyy',
      endDate: "today",
      maxDate: today
       });	 
</script>
<script>
   function ValidatePhoneNo() {
     if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
       return event.returnValue;
     return event.returnValue = '';
   }
</script>