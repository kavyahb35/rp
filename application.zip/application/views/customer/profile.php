<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
         <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block"> Profile</h3>
            <div class="row breadcrumbs-top d-inline-block">
               <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Dashboard</a>
                     </li>
                  </ol>
               </div>
            </div>
         </div>
      </div>
      <div class="content-body">
         <div class="row">
            <div class="col-12 col-md-12">
               <!-- User Profile -->
               <section class="card">
                  <div class="card-content">
                     <div class="card-body">
                        <div class="col-12">
                           <div class="row">
                              <div class="col-md-12 col-12">
                                 <div class="row">
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">Transactions</p>
                                       <p class="mb-0">12/14</p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">Last login</p>
                                       <p class="mb-0"><?php echo $this->session->userdata['customerprofiles']['lastUpdate'];?></p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                       <p class="text-bold-700 text-uppercase mb-0">IP</p>
                                       <p class="mb-0"><?php echo $this->input->server('REMOTE_ADDR');?></p>
                                    </div>
                                 </div>
                                 <hr/>
                                 <?php if(!empty($error)){?>
                                 <div class="alert alert-danger  alert-dismissible msg">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $error;?>
                                 </div>
                                 <?php } ?>
                                 <?php if(!empty($success)){?>
                                 <div class="alert alert-success  alert-dismissible msg">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;
                                    </a>
                                    <?php  echo $success;?>
                                 </div>
                                 <?php } ?>
                                 <form class="form-horizontal form-user-profile row mt-2" action="<?php echo base_url('update-profile'); ?>" method="post" name="registerfrm" id="registerfrm">
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" name="firstname" class="form-control" id="firstname" value="<?php echo $this->session->userdata['customerprofiles']['firstName'];?>" readonly>
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" name="lastname" class="form-control" id="lastname" value="<?php echo $this->session->userdata['customerprofiles']['lastName'];?>" readonly>
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="email" name="email" value="<?php echo $this->session->userdata['customerprofiles']['userEmail'];?>" placeholder="Enter Email Id" readonly>
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone" value="<?php echo $this->session->userdata['customerprofiles']['phone'];?>"  placeholder="Enter Phone" onkeypress="return ValidatePhoneNo()" maxlength="12">
                                       </fieldset>
                                    </div>
                                    <div class="col-12">
                                       <?php $fulladdress = $this->session->userdata['customerprofiles']['address'];
                                          $all=  explode('|', $fulladdress);
                                          $address = $all[0];
                                          $city = $all[1];
                                          $province_state = $all[2];
                                          $zipcode = $all[3];
                                          $country = $all[4];
                                          $province = trim($province_state);
                                          ?>
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="address" name="address" value="<?php echo $address;?>"  placeholder="Enter Address" />
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="city" placeholder="Enter city" name="city" placeholder="City " value="<?php echo $city;?>"   /> 												   
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <select name="province" id="province" class="form-control">
                                          <?php if($province==''){ ?> 
                                          <option value="">- Province - </option>
                                          <?php } ?>
                                          <option value="Alberta" <?php if($province=='Alberta'){ echo 'selected=selected';}?>>Alberta</option>
                                          <option value="British Columbia" <?php if($province=='British Columbia'){ echo 'selected=selected';}?>>British Columbia</option>
                                          <option value="Manitoba" <?php if($province=='Manitoba'){ echo 'selected=selected';}?>>Manitoba</option>
                                          <option value="New Brunswick" <?php if($province=='New Brunswick'){ echo 'selected=selected';}?>>New Brunswick</option>
                                          <option value="Newfoundland and Labrador" <?php if($province=='Newfoundland and Labrador'){ echo 'selected=selected';}?>>Newfoundland and Labrador</option>
                                          <option value="Northwest Territories" <?php if($province=='Northwest Territories'){ echo 'selected=selected';}?>>Northwest Territories</option>
                                          <option value="Nova Scotia" <?php if($province=='Nova Scotia'){ echo 'selected=selected';}?>>Nova Scotia</option>
                                          <option value="Nunavut" <?php if($province=='Nunavut'){ echo 'selected=selected';}?>>Nunavut</option>
                                          <option value="Ontario" <?php if($province=='Ontario'){ echo 'selected=selected';}?>>Ontario</option>
                                          <option value="Prince Edward Island" <?php if($province=='Prince Edward Island'){ echo 'selected=selected';}?>>Prince Edward Island</option>
                                          <option value="Québec" <?php if($province=='Québec'){ echo 'selected=selected';}?>>Québec</option>
                                          <option value="Saskatchewan" <?php if($province=='Saskatchewan'){ echo 'selected=selected';}?>>Saskatchewan</option>
                                          <option value="Yukon Territory" <?php if($province=='Yukon Territory'){ echo 'selected=selected';}?>>Yukon Territory</option>
                                       </select>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="zipcode" placeholder="Enter Postcode" name="zipcode" value="<?php echo $zipcode;?>"   maxlength="7" >												   
                                       </fieldset>
                                    </div>
                                    <div class="col-6">
                                       <fieldset class="form-label-group">
                                          <input type="text" class="form-control" id="country" name="country"  placeholder="Country *"  value="CA" readonly />
                                       </fieldset>
                                    </div>
                                    <div class="col-12 text-right">
                                       <button type="submit" class="btn-gradient-primary my-1" id="btn-submit">Save  <span id="loadingImg" style="display:none"><img src="<?php echo base_url('assets/front/loader/spin.gif')?>"></span></button>
                                    </div>
                                 </form>
                                 <script src="<?php echo base_url('assets/front/home/assets/js/datetimepicker/jquery.validate.min.js');?>"></script>
                                 <script>
                                    //form validation rules
                                    $("#registerfrm").validate({
                                        rules: {
                                            firstname: "required",
                                            lastname: "required",
                                            address: "required",
                                            city: "required",
                                            province:"",
                                            phone: "required",
                                            email: "required",
                                        },
                                        messages: {
                                            firstname: "",
                                            lastname: "",
                                            address: "",
                                            city:"",
                                            province:"",
                                            phone: "",
                                            email: "",
                                        },
                                        submitHandler: function(form) {
                                            $("#num").hide();
                                            form.submit();
                                            $("#loadingImg").show();
                                            $(this).find("#btn-submit").prop('disabled', true);
                                        }
                                    });
                                 </script>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
            </div>           
         </div>
      </div>
   </div>
</div>
<script>
   $('#date').datetimepicker({
   	format: 'dd/mm/yyyy',
   	endDate: new Date(), 
        maxDate: new Date() 
   });	 
</script>
<script>
   function ValidatePhoneNo() {
   	if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
   	return event.returnValue;
   	return event.returnValue = '';
   }
</script>