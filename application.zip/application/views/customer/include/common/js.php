<script src="<?php echo base_url('assets/front/customer/');?>app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="<?php echo base_url('assets/front/customer/');?>app-assets/js/core/app.js" type="text/javascript"></script>