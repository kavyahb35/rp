<nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-light navbar-bg-color customer-layout">
   <div class="navbar-wrapper">
      <div class="navbar-header d-md-none">
         <ul class="nav navbar-nav flex-row">
            <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
            <li class="nav-item d-md-none"><a class="navbar-brand" href="<?php echo base_url('dashboard');?>"><img class="brand-logo d-none d-md-block" alt="R2P logo" src="<?php echo base_url('assets/front/customer/');?>app-assets/images/logo/logo.png">
               <img class="brand-logo d-sm-block d-md-none" alt="R2P logo sm" src="<?php echo base_url('assets/front/');?>customer/app-assets/images/logo/logo-sm.png"></a>
            </li>
            <li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v">   </i></a></li>
         </ul>
      </div>
      <div class="navbar-container">
         <div class="collapse navbar-collapse" id="navbar-mobile">
            <ul class="nav navbar-nav mr-auto float-left">
               <li class="nav-item d-none d-md-block left-li"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu">  </i></a></li>
               <li class="nav-item nav-search left-li">
                  <div class="">
                  </div>
               </li>
            </ul>
            <ul class="nav navbar-nav float-right">
               <li class="dropdown dropdown-notification nav-item right-li"><a class="nav-link nav-link-label" href="<?php echo base_url('wallet');?>"><i class="ficon icon-wallet"></i></a></li>
               <li class="dropdown dropdown-user nav-item right-li">
                  <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">             
                  <span class="avatar avatar-online">
                  <img src="<?php echo base_url('assets/front/customer/');?>app-assets/images/portrait/small/avatar-user.png" alt="avatar" />
                  </span>
                  <span class="mr-1"><?php echo $this->session->userdata['customerDetails']['firstName'];?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right">
                     <a class="dropdown-item" href=""><i class="ft-award"></i><?php 
                        $firstName = $this->session->userdata['customerDetails']['firstName'];                        
                        $lastName = $this->session->userdata['customerDetails']['lastName'];
                        echo $firstName.' '.$lastName;
                        ?></a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="<?php echo base_url('profile');?>"><i class="ft-user"></i> Profile</a>
                     <a class="dropdown-item" href="<?php echo base_url('user/changepassword');?>"><i class="ft-lock"></i> Change Password</a>
                     <a class="dropdown-item" href="<?php echo base_url('wallet');?>"><i class="icon-wallet"></i> My Wallet</a><a class="dropdown-item" href="<?php echo base_url('transaction');?>"><i class="ft-check-square"></i> Transactions              </a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item" href="<?php echo base_url('logout');?>"><i class="ft-power"></i> Logout</a>
                  </div>
               </li>
            </ul>
         </div>
      </div>
   </div>
</nav>
<div class="main-menu menu-fixed menu-dark menu-bg-default rounded menu-accordion menu-shadow">
   <div class="main-menu-content">
      <a class="navigation-brand d-none d-md-block d-lg-block d-xl-block" href=""><img class="brand-logo" alt="crypto ico admin logo" src="<?php echo base_url('assets/front/customer/');?>app-assets/images/logo/logo.png"/></a>
      <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
         <li <?php if(current_url()==base_url('dashboard')) { echo 'class="active"';}else { 'class="nav-item"';}?>><a href="<?php echo base_url('dashboard');?>"><i class="icon-grid"></i><span class="menu-title" data-i18n="">Dashboard</span></a>
         </li>
         <li <?php if(current_url()==base_url('manage-cards')) { echo 'class="active"';}else { 'class="nav-item"';}?>><a href="<?php echo base_url('manage-cards');?>"><i class="icon-layers"></i><span class="menu-title" data-i18n="">Cards</span></a>
         </li>
         <li <?php if(current_url()==base_url('wallet')) { echo 'class="active"';}else { 'class="nav-item"';}?>><a href="<?php echo base_url('wallet');?>"><i class="icon-wallet"></i><span class="menu-title" data-i18n="">Wallet</span></a>
         </li>
         <li <?php if(current_url()==base_url('transaction')) { echo 'class="active"';}else { 'class="nav-item"';}?>><a href="<?php echo base_url('transaction');?>"><i class="icon-shuffle"></i><span class="menu-title" data-i18n="">Transactions</span></a>
         </li>
         <li <?php if(current_url()==base_url('faq')) { echo 'class="active"';}else { 'class="nav-item"';}?>><a href="<?php echo base_url('faq')?>" ><i class="icon-support"></i><span class="menu-title" data-i18n="">FAQ</span></a>
         </li>
         <li class=" nav-item">
            <a href="<?php echo base_url('profile');?>"><i class="icon-user-following"></i><span class="menu-title" data-i18n="">Account</span></a>
         </li>
      </ul>
   </div>
</div>