<div class="app-content content">
   <div class="content-wrapper">
      <div class="content-header row">
         <div class="content-header-left col-md-8 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">FAQ</h3>
            <div class="row breadcrumbs-top d-inline-block">
               <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb">
                     <li class="breadcrumb-item"><a href="<?php echo base_url('dashboard')?>">Dashboard</a>
                     </li>
                     <li class="breadcrumb-item active">FAQ
                     </li>
                  </ol>
               </div>
            </div>
         </div>
         <div class="content-header-right col-md-4 col-12 d-none d-md-inline-block">
            <div class="btn-group float-md-right"><a class="btn-gradient-secondary btn-sm white" href="<?php echo base_url('wallet') ?>">Redeem</a></div>
         </div>
      </div>
      <div class="content-body">
         <div class="row">
            <div class="col-md-10 col-12  order-2">
               <div class="tab-content" id="v-pills-tabContent">
                  <?php if(!empty($faqs)){ $j=1;
                     foreach($faqs as $faqstit){	 
                      $title = $faqstit['title'];
                      $slug = $faqstit['slug']; 
                       $sections = $faqstit['sections'];
                        ?>
                  <div class="tab-pane fade  <?php  if($j=='1') { echo 'active active show';}?> " id="v-pills-<?php echo $slug;?>" role="tabpanel" aria-labelledby="v-pills-<?php echo $slug;?>-tab">
                     <div id="accordion<?php echo $j;?>" class="collapse-icon accordion-icon-rotate left">
                        <?php if(!empty($sections)){ $i=1;
                           foreach($sections as $sec){
                           ?>
                        <div class="card">
                           <div class="card-header" id="heading<?php echo $j.$i;?>">
                              <a class="card-title lead collapsed" data-toggle="collapse" data-target="#collapse<?php echo  $j.$i;?>" aria-expanded="false" aria-controls="collapse<?php echo  $j.$i;?>" href="#">
                              <?php echo $sec['question'];?></a>
                           </div>
                           <div id="collapse<?php echo  $j.$i;?>" class="collapse <?php if($i=='1'){ echo 'show';}?> " aria-labelledby="heading<?php echo  $j.$i;?>" data-parent="#accordion<?php echo $j;?>">
                              <div class="card-body">
                                 <?php echo $sec['answer'];?>    
                              </div>
                           </div>
                        </div>
                        <?php $i++;}
                           } ?>
                     </div>
                  </div>
                  <?php $j++; }
                     } ?>								
               </div>
            </div>
            <div class="col-md-2 col-12 order-1">
               <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                  <?php if(!empty($faqs)){ 
                        $i=1;
                        foreach($faqs as $faqstit){											  
                        $title = $faqstit['title'];
                        $slug = $faqstit['slug']; ?>
                        <a class="nav-link <?php if($i=='1'){ echo 'active show';} ?> " id="v-pills-<?php echo $slug;?>-tab" data-toggle="pill" href="#v-pills-<?php echo $slug;?>" role="tab" aria-controls="v-pills-<?php echo $slug;?>" aria-selected="<?php if($i=='1'){ echo 'true';}else { echo 'false';}?>"><?php echo $title;?></a>
                  <?php
                        $i++;}
                    }?>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<style>.card .card-title { font-weight:300; } li {
   list-style: none;
   }
</style>